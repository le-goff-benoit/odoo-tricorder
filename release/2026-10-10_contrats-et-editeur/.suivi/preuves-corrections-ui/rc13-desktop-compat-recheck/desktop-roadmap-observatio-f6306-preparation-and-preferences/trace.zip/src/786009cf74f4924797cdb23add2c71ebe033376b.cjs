const { test, expect, _electron: electron } = require('@playwright/test');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { cleanupBroker } = require('./terminal-fixture.cjs');
const root = path.resolve(__dirname, '..');

function write(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, typeof value === 'object' ? JSON.stringify(value, null, 2) : value);
}
function fixture(home) {
  const project = path.join(home, 'orbital-industries');
  const releaseId = '2026-09-11_01_facturation-et-maintenance';
  const release = path.join(project, 'changelog', releaseId);
  write(path.join(project, '.odoo-agents/config'), 'series = 19.0\n');
  write(path.join(project, 'orbital_custom/__manifest__.py'), "{'name': 'Orbital', 'version': '19.0.1.0.0'}\n");
  write(path.join(project, '.odoo-agents/PROJECT.md'), '# Orbital Industries\n\nProjet synthétique de démonstration.');
  write(path.join(project, '.odoo-agents/JOURNAL.md'), '# Journal\n\nLe suivi des missions est opérationnel.');
  write(path.join(project, '.odoo-agents/instances.json'), {
    local: { kind: 'local', url: 'http://localhost:8069', db: 'orbital_test', platform: 'docker' },
    staging: { kind: 'staging', url: 'https://staging.example.test', db: 'orbital_staging', platform: 'odoo.sh' },
    production: { kind: 'production', url: 'https://example.test', db: 'orbital', platform: 'odoo.sh' },
  });
  write(path.join(release, 'README.md'), '<!-- release ouverte -->\n# Facturation & maintenance récurrente\n\nUne release synthétique pour les tests du cockpit.');
  write(path.join(release, 'demande.md'), '# Demande\n\nFiabiliser la facturation et les interventions récurrentes.');
  const source = { path: `changelog/${releaseId}/demande.md`, sha256: require('node:crypto').createHash('sha256').update(fs.readFileSync(path.join(release, 'demande.md'))).digest('hex') };
  write(path.join(release, 'knowledge/K01.json'), { schema: 1, id: 'K01', kind: 'question', state: 'proposed',
    statement: 'Préciser l’exception pour la société B.', author: 'Codex · analyste', scope: [], sources: [source] });
  const task = (id, title, extra = {}) => ({ id, title, request: `changelog/${releaseId}/demande.md`,
    acceptance: ['Les scénarios ciblés sont vérifiés sur copie locale.', 'Les résultats sont associés à une preuve.'],
    risk: 'normal', route: 'module', scopes: ['orbital_custom'], depends_on: [], ...extra });
  write(path.join(release, 'plan.json'), { schema: 1, tasks: [
    task('T01', 'Fiabiliser les factures partielles', { receipt: { contract_sha256: 'old' }, risk: 'high' }),
    task('T02', 'Planifier les interventions récurrentes', { attempts: [{ flow: '.odoo-agents/flows/maintenance.json' }] }),
    task('T03', 'Recetter les documents de la release', { depends_on: ['T01', 'T02'] }),
  ] });
  const nodes = { review: { description: 'Revue fonctionnelle', executor: 'agent', role: 'odoo-analyst' },
    build: { description: 'Développement du module', executor: 'agent', role: 'odoo-developer', locks: [] },
    qa: { description: 'Validation sur copie locale', executor: 'agent', role: 'odoo-tester', locks: [] } };
  write(path.join(project, '.odoo-agents/flows/maintenance.json'), { schema_version: 1, run_id: 'maintenance',
    project, kind: 'development', status: 'active', created_at: '2026-09-11T09:00:00Z', updated_at: '2026-09-11T09:12:00Z',
    graph_snapshot: { start: 'review', nodes, edges: [{ id: 'a', from: 'review', to: 'build', outcome: 'done' }, { id: 'b', from: 'build', to: 'qa', outcome: 'done' }] },
    events: [{ node: 'review', at: '2026-09-11T09:05:00Z', outcome: 'done', note: 'Périmètre et critères vérifiés.' }], tokens: {},
    claims: { build: { owner: 'Codex · développeur', at: '2026-09-11T09:12:00Z', locks: [{ resource: 'orbital_custom', mode: 'write' }] } } });
  write(path.join(home, 'nova-services/.odoo-agents/config'), 'series = 18.0\n');
  write(path.join(home, 'equinox-studio/.odoo-agents/config'), 'series = 19.1\n');
  return { project, releaseId };
}

async function closeWindow(app) {
  await app.close();
}

async function projectTab(page, view) {
  const button = page.locator(`#tabs [data-view="${view}"]`);
  await button.click();
}

async function projectView(page, view) {
  await projectTab(page, 'work');
  await page.locator('details').filter({hasText:'Outils du projet'}).locator('summary').click();
  await page.locator(`.work-page [data-view="${view}"]`).click();
  await expect(page.locator('#context-bar')).toBeHidden();
}

async function kanbanMode(page) {
  await projectTab(page, 'plan');
  await page.locator('[data-plan-mode="kanban"]').click();
}

test('simplified workspace: task dialogs, agent identity, preferences and launch buttons', async () => {
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'tri-simple-'));
  const home = path.join(temp, 'home'); fs.mkdirSync(home);
  const { project, releaseId } = fixture(home);
  // These functions shadow real executables: no provider call or token usage.
  write(path.join(home, '.bashrc'), `claude() { printf 'FAKE-CLAUDE:%s\\n' "$PWD"; }\ncodex() { printf 'FAKE-CODEX:%s\\n' "$PWD"; }\n`);
  const app = await electron.launch({ args: process.env.TRICORDER_EXECUTABLE ? [] : [root],
    ...(process.env.TRICORDER_EXECUTABLE ? { executablePath: process.env.TRICORDER_EXECUTABLE } : {}),
    env: { ...process.env, SHELL: '/bin/bash', HOME: home, TRICORDER_HOME: home,
      TRICORDER_AGENTS_DIR: process.env.TRICORDER_AGENTS_DIR || path.join(os.homedir(), '.odoo19-agents'),
      TRICORDER_STATE_DIR: path.join(temp, 'state'), TRICORDER_RUNTIME_DIR: path.join(temp, 'run') } });
  const errors = [];
  try {
    const page = await app.firstWindow(); page.on('pageerror', e => errors.push(e.message));
    await expect(page.locator('#release-select')).toHaveValue(releaseId);
    await page.setViewportSize({ width: 1280, height: 900 });
    await expect(page.locator('#task-select, .terminal-footer, .statusbar')).toHaveCount(0);
    await expect(page.locator('#inspector')).toBeHidden();
    await projectTab(page, 'work');
    await expect(page.locator('.work-page')).toContainText('Préciser l’exception pour la société B.');
    await page.screenshot({ path: 'test-results/memoire-release.png' });
    const memoryPath = path.join(project, 'changelog', releaseId, 'knowledge/K01.json');
    const nextMemory = JSON.parse(fs.readFileSync(memoryPath));
    nextMemory.id = 'K02'; nextMemory.statement = 'Découverte partagée pendant la tâche.';
    write(path.join(project, 'changelog', releaseId, 'knowledge/K02.json'), nextMemory);
    await expect(page.locator('.work-page')).toContainText('Découverte partagée pendant la tâche.', { timeout: 15000 });
    await projectTab(page, 'terminal');
    // Tabs are plain labels; their Alt shortcut is announced, not drawn.
    await expect(page.locator('#tabs [data-view="terminal"]')).toHaveAttribute('aria-keyshortcuts', 'Alt+2');
    await expect(page.locator('#tabs [data-view="express"]')).toHaveAttribute('aria-keyshortcuts', 'Alt+6');
    await page.locator('[data-launch-agent="claude"]').evaluate(button => { button.click(); button.click(); });
    await expect(page.locator('.xterm-screen')).toContainText('FAKE-CLAUDE:' + project);
    const [before] = await page.evaluate(() => window.tricorder.terminals.list());
    expect((await page.evaluate(() => window.tricorder.terminals.list())).length).toBe(1);
    expect(before.task).toBeNull();
    await kanbanMode(page);
    await page.locator('[data-release-task="T02"]').click();
    await expect(page.locator('#task-modal')).toBeVisible();
    await expect(page.locator('#task-modal')).toHaveAttribute('aria-labelledby', 'task-modal-title');
    await expect(page.locator('.board-criteria li')).toHaveCount(2);
    await expect(page.locator('#task-modal')).toContainText('odoo-analyst');
    await expect(page.locator('#task-modal')).toContainText('odoo-developer');
    await page.screenshot({ path: 'test-results/task-modal-simplified.png' });
    await page.keyboard.press('Escape');
    await expect(page.locator('#task-modal')).not.toBeVisible();
    await expect(page.locator('[data-release-task="T02"]')).toBeFocused();
    await expect(page.locator('.release-kanban .kanban-card')).toHaveCount(3);
    await page.screenshot({ path: 'test-results/kanban-simplified.png' });
    await projectTab(page, 'effort');
    await expect(page.locator('[data-cockpit="associate"], .open-timers, .effort-live-hint')).toHaveCount(0);
    const row = page.locator('[data-time-task="T02"]');
    await row.locator('summary').click();
    await expect(row).toContainText('odoo-analyst');
    await expect(row).toContainText('À compléter');
    await expect(row).toContainText('odoo-developer');
    await page.locator('[data-cockpit="preferences"]').click();
    await expect(page.locator('.preferences h2')).toHaveText('Paramètres');
    await expect(page.locator('#pref-inspector')).toHaveCount(0);
    await page.locator('#pref-size').fill('99');
    await page.locator('#preferences-form button[type=submit]').click();
    await expect(page.locator('#modal')).toBeVisible();
    await page.locator('#pref-size').fill('16');
    await page.locator('#pref-contrast').check();
    await page.screenshot({ path: 'test-results/preferences-simplified.png' });
    await page.locator('#preferences-form button[type=submit]').click();
    await page.locator('[data-cockpit="preferences"]').click();
    await expect(page.locator('#pref-size')).toHaveValue('16');
    await page.locator('#pref-size').fill('18');
    await page.locator('[data-action="cancel-preferences"]').click();
    await page.locator('[data-cockpit="preferences"]').click();
    await expect(page.locator('#pref-size')).toHaveValue('16');
    await page.locator('.modal-close').click();
    const [after] = await page.evaluate(() => window.tricorder.terminals.list());
    expect([after.id, after.pid, after.task, after.release]).toEqual([before.id, before.pid, null, releaseId]);
    await page.locator('[data-project]').filter({ hasText: 'nova-services' }).click();
    await projectTab(page, 'terminal');
    await page.locator('[data-launch-agent="codex"]').click();
    await expect(page.locator('.terminal-host:visible .xterm-screen')).toContainText('FAKE-CODEX:' + path.join(home, 'nova-services'));
    expect((await page.evaluate(() => window.tricorder.terminals.list())).length).toBe(2);
    expect(errors).toEqual([]);
  } finally {
    await closeWindow(app).catch(() => app.process().kill('SIGKILL'));
    await cleanupBroker(path.join(temp, 'run/pty.sock')); fs.rmSync(temp, { recursive: true, force: true });
  }
});

test('global Kanban: all projects, closed-release filter and exact task navigation', async () => {
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'tri-kanban-'));
  const home = path.join(temp, 'home'); fs.mkdirSync(home);
  const { project, releaseId } = fixture(home);
  const second = path.join(home, 'nova-services'), oldId = '2026-08-01_01_archive';
  const originalPlan = JSON.parse(fs.readFileSync(path.join(project, 'changelog', releaseId, 'plan.json')));
  const definition = { schema: 1, tasks: [{ ...originalPlan.tasks[2], id: 'T01', title: 'Contrôler les livraisons Nova',
    request: `changelog/${releaseId}/demande.md`, scopes: [], depends_on: [] }] };
  write(path.join(second, 'changelog', releaseId, 'README.md'), '<!-- release ouverte -->\n# Livraisons Nova\n');
  write(path.join(second, 'changelog', releaseId, 'demande.md'), '# Demande Nova\n');
  write(path.join(second, 'changelog', releaseId, 'plan.json'), definition);
  write(path.join(project, 'changelog', oldId, 'README.md'), '# Archive Orbital\n');
  write(path.join(project, 'changelog', oldId, 'plan.json'), { schema: 1, tasks: [originalPlan.tasks[2]] });
  const app = await electron.launch({ args: process.env.TRICORDER_EXECUTABLE ? [] : [root],
    ...(process.env.TRICORDER_EXECUTABLE ? { executablePath: process.env.TRICORDER_EXECUTABLE } : {}),
    env: { ...process.env, HOME: home, TRICORDER_HOME: home,
      TRICORDER_AGENTS_DIR: process.env.TRICORDER_AGENTS_DIR || path.join(os.homedir(), '.odoo19-agents'),
      TRICORDER_STATE_DIR: path.join(temp, 'state'), TRICORDER_RUNTIME_DIR: path.join(temp, 'run') } });
  try {
    const page = await app.firstWindow();
    if (!(await page.locator('.sidebar-tools').evaluate(el => el.open))) await page.locator('.sidebar-tools > summary').click();
    await page.locator('[data-view="kanban"]').click();
    await expect(page.locator('#project-title')).toHaveText('Kanban global');
    await expect(page.locator('#context-bar')).toBeHidden();
    await expect(page.locator('.kanban-card')).toHaveCount(4);
    await expect(page.locator('.kanban-board')).toContainText('orbital-industries');
    await expect(page.locator('.kanban-board')).toContainText('nova-services');
    await expect(page.locator('.kanban-board')).toContainText('Codex · développeur');
    await expect(page.locator('.kanban-card[draggable="true"]')).toHaveCount(0);
    await expect(page.locator('.kanban-board')).toBeInViewport();
    await page.locator('[data-action="kanban-closed"]').click();
    await expect(page.locator('.kanban-card')).toHaveCount(5);
    await expect(page.locator('.kanban-board')).toContainText('Archive Orbital');
    await page.locator('[data-action="refresh"]').evaluate(el => el.click());
    await expect(page.locator('#sync-status')).toContainText('À jour');
    await expect(page.locator('.kanban-card')).toHaveCount(5);
    await page.screenshot({ path: 'test-results/global-kanban.png' });
    await page.locator('.kanban-card').filter({ hasText: 'Contrôler les livraisons Nova' }).click();
    await expect(page.locator('#project-title')).toHaveText('nova-services');
    await expect(page.locator('#release-select')).toHaveValue(releaseId);
    await expect(page.locator('#task-modal')).toContainText('Contrôler les livraisons Nova');
    expect(JSON.parse(fs.readFileSync(path.join(second, 'changelog', releaseId, 'plan.json')))).toEqual(definition);
  } finally {
    await closeWindow(app).catch(() => app.process().kill('SIGKILL'));
    await cleanupBroker(path.join(temp, 'run/pty.sock'));
    fs.rmSync(temp, { recursive: true, force: true });
  }
});

test('release Kanban: receipts, criteria, filters, live refresh and existing terminal stay scoped', async () => {
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'tri-release-board-'));
  const home = path.join(temp, 'home'); fs.mkdirSync(home);
  const { project, releaseId } = fixture(home);
  const planFile = path.join(project, 'changelog', releaseId, 'plan.json');
  const planBefore = fs.readFileSync(planFile, 'utf8');
  write(path.join(project, 'changelog', releaseId, 'junit-targeted.xml'), '<testsuite tests="12" failures="0" errors="0" skipped="2"><properties><property name="odoo.task" value="T02"/></properties></testsuite>');
  write(path.join(project, 'changelog', releaseId, 'effort.json'), { schema: 1, release: releaseId,
    tasks: { T02: 'Planifier les interventions récurrentes' }, estimates: [], rate_cards: [],
    entries: [{ id: 'a', task: 'T02', agent: 'odoo-analyst', status: 'complete', seconds: 600 }] });
  const oldId = '2026-09-10_01_archive';
  write(path.join(project, 'changelog', oldId, 'README.md'), '# Ancienne release\n');
  write(path.join(project, 'changelog', oldId, 'plan.json'), { schema: 1, tasks: [
    { ...JSON.parse(planBefore).tasks[2], id: 'T02', title: 'Autre tâche homonyme', depends_on: [] } ] });
  const app = await electron.launch({ args: process.env.TRICORDER_EXECUTABLE ? [] : [root],
    ...(process.env.TRICORDER_EXECUTABLE ? { executablePath: process.env.TRICORDER_EXECUTABLE } : {}),
    env: { ...process.env, HOME: home, TRICORDER_HOME: home,
      TRICORDER_AGENTS_DIR: process.env.TRICORDER_AGENTS_DIR || path.join(os.homedir(), '.odoo19-agents'),
      TRICORDER_STATE_DIR: path.join(temp, 'state'), TRICORDER_RUNTIME_DIR: path.join(temp, 'run') } });
  const errors = [];
  try {
    const page = await app.firstWindow(); page.on('pageerror', error => errors.push(error.message));
    await expect(page.locator('#release-select')).toHaveValue(releaseId);
    await page.keyboard.press('Control+Shift+T');
    await expect(page.locator('.terminal-tab')).toHaveCount(1);
    const [terminal] = await page.evaluate(() => window.tricorder.terminals.list());
    await kanbanMode(page);
    await expect(page.locator('.release-kanban .kanban-card')).toHaveCount(3);
    await expect(page.locator('.release-kanban [data-column="review"]')).toContainText('T01');
    await expect(page.locator('.board-count')).toContainText('1 tâche réalisée · 3 tâches');
    await expect(page.locator('.release-kanban [data-column="review"]')).toContainText('Tests à actualiser');
    await page.locator('[data-release-task="T02"]').click();
    await expect(page.locator('.board-criteria li')).toHaveCount(2);
    await expect(page.locator('.board-detail')).toContainText('0 h 10 min');
    await expect(page.locator('.board-detail')).toContainText('10 exécutés');
    await expect(page.locator('.release-kanban .kanban-card')).toHaveCount(3);
    await page.locator('[data-board-close]').click();
    await page.locator('[data-plan-filter="blocked"]').click();
    await expect(page.locator('.release-kanban .kanban-card')).toHaveCount(0);
    await page.locator('[data-plan-filter="all"]').click();
    // A short window forces the dialog to scroll so the position survives a refresh.
    await page.setViewportSize({ width: 1280, height: 560 });
    await page.locator('[data-release-task="T02"]').click();
    const scrollBeforeRefresh = await page.locator('#task-modal').evaluate(el => { el.scrollTop = 180; return el.scrollTop; });
    expect(scrollBeforeRefresh).toBeGreaterThan(0);
    await page.locator('[data-action="refresh"]').evaluate(el => el.click());
    await expect(page.locator('#sync-status')).toContainText('À jour');
    await expect(page.locator('.board-detail')).toContainText('Planifier les interventions');
    expect(await page.locator('#task-modal').evaluate(el => el.scrollTop)).toBe(scrollBeforeRefresh);
    await page.screenshot({ path: 'test-results/release-kanban.png' });
    await page.locator('.board-detail [data-session]').click();
    await expect(page.locator('#terminal-workspace')).toBeVisible();
    const after = await page.evaluate(() => window.tricorder.terminals.list());
    expect(after.length).toBe(1); expect(after[0].id).toBe(terminal.id); expect(after[0].pid).toBe(terminal.pid);
    expect(after[0].task).toBeNull();
    await kanbanMode(page);
    await page.locator('#release-select').selectOption(oldId);
    await expect(page.locator('.board-detail')).toHaveCount(0);
    await expect(page.locator('.release-kanban .kanban-card')).toHaveCount(1);
    await expect(page.locator('.release-kanban')).toContainText('Autre tâche homonyme');
    await page.locator('#release-select').selectOption(releaseId);
    await expect(page.locator('#task-modal')).not.toBeVisible();
    await page.locator('[data-release-task="T02"]').click();
    await expect(page.locator('.board-detail')).toContainText('Planifier les interventions');
    // An agent updates the plan on disk: refresh must update cards without changing context.
    const updated = JSON.parse(planBefore); updated.tasks[1].title = 'Interventions mises à jour'; write(planFile, updated);
    await page.locator('[data-action="refresh"]').evaluate(el => el.click());
    await expect(page.locator('.board-detail h2')).toHaveText('Interventions mises à jour');
    await app.evaluate(({ BrowserWindow }) => { const win = BrowserWindow.getAllWindows()[0]; win.setMinimumSize(800, 600); win.setSize(1000, 800); });
    await expect(page.locator('[data-board-close]')).toBeInViewport();
    await page.screenshot({ path: 'test-results/release-kanban-compact.png' });
    await page.locator('[data-board-close]').click();
    await expect(page.locator('.board-detail')).toHaveCount(0);
    await page.locator('#release-select').selectOption('');
    await expect(page.locator('.no-release')).toContainText('Aucune release sélectionnée');
    await expect(page.locator('.board-detail')).toHaveCount(0);
    expect(JSON.parse(fs.readFileSync(planFile))).toEqual(updated);
    expect(errors).toEqual([]);
  } finally {
    await closeWindow(app).catch(() => app.process().kill('SIGKILL'));
    await cleanupBroker(path.join(temp, 'run/pty.sock'));
    fs.rmSync(temp, { recursive: true, force: true });
  }
});

test('design system: common gutters, cards and controls across every project view', async () => {
  test.setTimeout(90000);
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'tri-design-'));
  const home = path.join(temp, 'home'); fs.mkdirSync(home);
  fixture(home);
  const app = await electron.launch({ args: process.env.TRICORDER_EXECUTABLE ? [] : [root],
    ...(process.env.TRICORDER_EXECUTABLE ? { executablePath: process.env.TRICORDER_EXECUTABLE } : {}),
    env: { ...process.env, HOME: home, TRICORDER_HOME: home,
      TRICORDER_AGENTS_DIR: process.env.TRICORDER_AGENTS_DIR || path.join(os.homedir(), '.odoo19-agents'),
      TRICORDER_STATE_DIR: path.join(temp, 'state'), TRICORDER_RUNTIME_DIR: path.join(temp, 'run') } });
  const errors = [];
  try {
    const page = await app.firstWindow(); page.on('pageerror', e => errors.push(e.message));
    await expect(page.locator('#release-select')).not.toHaveValue('');
    for (const [width, height, zoom, gutter] of [[1440, 900, 1, 24], [1000, 900, 1, 16], [1000, 700, 1.25, 16]]) {
      await app.evaluate(({ BrowserWindow }, width) => { const w = BrowserWindow.getAllWindows()[0]; w.setMinimumSize(800, 600); w.setSize(width, 900); }, width);
      // A tiling desktop can refuse setSize. Exercise the CSS viewport explicitly.
      await app.evaluate(({ BrowserWindow }, zoom) => BrowserWindow.getAllWindows()[0].webContents.setZoomFactor(zoom), zoom);
      await page.setViewportSize({ width, height });
      await expect.poll(() => page.evaluate(() => window.innerWidth)).toBe(Math.floor(width / zoom));
      for (const view of ['intentions', 'plan', 'release-kanban', 'knowledge', 'express', 'work', 'effort', 'documents', 'sources', 'environments']) {
        if (['documents', 'sources', 'environments'].includes(view)) await projectView(page, view);
        else if (view === 'release-kanban') await kanbanMode(page);
        else if (view === 'plan') { await projectTab(page, 'plan'); await page.locator('[data-plan-mode="list"]').click(); }
        else await projectTab(page, view);
        await expect(page.locator('#content > .page')).toBeVisible();
        if (view !== 'work') await expect(page.locator('#terminal-workspace')).toBeHidden();
        const styles = await page.evaluate(() => {
          const css = q => getComputedStyle(document.querySelector(q));
          return { page: css('#content > .page').paddingLeft, right: css('#content > .page').paddingRight,
            tabs: css('#tabs').paddingLeft, header: css('.project-header').paddingLeft,
            max: css('#content > .page').maxWidth,
            cards: [...document.querySelectorAll('#content .info-card, #content .agent-mission, #content .metric')].map(el => {
              const s = getComputedStyle(el); return [s.paddingLeft, s.paddingTop, s.borderRadius];
            }),
            gridMargins: [...document.querySelectorAll('.card-grid > .info-card')].map(el => getComputedStyle(el).margin),
            sectionGaps: [...document.querySelectorAll('.section-title.section-space')].map(el => getComputedStyle(el).marginTop),
            buttons: [...document.querySelectorAll('#content .secondary')].filter(el => el.offsetWidth).map(el => {
              const s = getComputedStyle(el); return [s.paddingLeft, s.paddingTop, s.minHeight];
            }),
            overflow: document.documentElement.scrollWidth > window.innerWidth,
          };
        });
        for (const key of ['page', 'right', 'tabs', 'header']) expect(styles[key], `${width} ${view} ${key}`).toBe(`${gutter}px`);
        expect(styles.max).toBe('none'); expect(styles.overflow, `${view} document overflow`).toBe(false);
        for (const card of styles.cards) expect(card, view).toEqual(['16px', '16px', '8px']);
        for (const margin of styles.gridMargins) expect(margin, 'Grid owns spacing, no double margin').toBe('0px');
        for (const margin of styles.sectionGaps) expect(margin, 'Section rhythm').toBe(`${gutter}px`);
        for (const button of styles.buttons) expect(button, view).toEqual(['12px', '8px', '36px']);
        await page.screenshot({ path: `test-results/design-${view}-${width}-${height}-zoom${zoom}.png` });
      }
      await page.locator('[data-cockpit="preferences"]').click();
      await expect(page.locator('#modal')).toBeVisible();
      expect(await page.locator('#modal').evaluate(el => getComputedStyle(el).padding)).toBe('24px');
      await page.locator('[data-action="modal-close"]').click();
    }
    expect(errors).toEqual([]);
  } finally {
    await closeWindow(app).catch(() => app.process().kill('SIGKILL'));
    await cleanupBroker(path.join(temp, 'run/pty.sock')); fs.rmSync(temp, { recursive: true, force: true });
  }
});

test('preparation: project scope becomes release scope without a duplicate or a retroactive forecast', async () => {
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'tri-preparation-'));
  const home = path.join(temp, 'home'); fs.mkdirSync(home);
  const project = path.join(home, 'atelier-orbital');
  write(path.join(project, '.odoo-agents/config'), 'series = 19.0\n');
  const file = path.join(project, '.odoo-agents/preparation/effort.json');
  const ledger = { schema: 1, release: 'preparation', tasks: { PREPARATION: 'Préparation du plan' },
    estimates: [], rate_cards: [], entries: [{ id: 'prep', task: 'PREPARATION', phase: 'preparation',
      release: null, agent: 'odoo-analyst', provider: 'codex', thread_id: 'prep-session', status: 'complete', seconds: 600,
      tokens: { input_tokens: 120, output_tokens: 30, cached_input_tokens: 40, cache_write_input_tokens: 0, total_tokens: 150 } }] };
  write(file, ledger);
  const app = await electron.launch({ args: process.env.TRICORDER_EXECUTABLE ? [] : [root],
    ...(process.env.TRICORDER_EXECUTABLE ? { executablePath: process.env.TRICORDER_EXECUTABLE } : {}),
    env: { ...process.env, HOME: home, TRICORDER_HOME: home,
      TRICORDER_AGENTS_DIR: process.env.TRICORDER_AGENTS_DIR || path.join(os.homedir(), '.odoo19-agents'),
      TRICORDER_STATE_DIR: path.join(temp, 'state'), TRICORDER_RUNTIME_DIR: path.join(temp, 'run') } });
  try {
    const page = await app.firstWindow();
    await app.evaluate(({ BrowserWindow }) => { const win = BrowserWindow.getAllWindows()[0]; win.setMinimumSize(800, 600); win.setSize(1000, 800); });
    await expect(page.locator('#release-select')).toHaveValue('');
    await projectTab(page, 'effort');
    await expect(page.locator('[data-time-task="PREPARATION"]')).toContainText('0 h 10 min');
    await expect(page.locator('[data-time-task="PREPARATION"]')).toContainText('150');
    await expect(page.locator('[data-time-task="PREPARATION"]')).toContainText('À compléter');
    const before = fs.readFileSync(file, 'utf8');
    await page.locator('[data-action="refresh"]').evaluate(el => el.click());
    await expect(page.locator('#sync-status')).toContainText('À jour');
    expect(fs.readFileSync(file, 'utf8')).toBe(before);

    // Simulate the agent's explicit attachment, not a cockpit write.
    const releaseId = '2026-09-11_01_organisation-des-interventions';
    const release = path.join(project, 'changelog', releaseId);
    write(path.join(release, 'README.md'), '<!-- release ouverte -->\n# Organisation des interventions\n');
    ledger.entries[0].release = releaseId; write(file, ledger);
    await page.locator('[data-action="refresh"]').evaluate(el => el.click());
    await expect(page.locator(`#release-select option[value="${releaseId}"]`)).toHaveCount(1);
    await page.locator('#release-select').selectOption(releaseId);
    await expect(page.locator('[data-time-task="PREPARATION"]')).toContainText('0 h 10 min');
    await expect(page.locator('.release-summary')).toContainText('Ouverte');
    await page.locator('[data-time-task="PREPARATION"] summary').click();
    await expect(page.locator('[data-time-task="PREPARATION"] [data-agent="odoo-analyst"]')).toContainText('0 h 10 min');
    await page.screenshot({ path: 'test-results/preparation-release.png' });
    expect(fs.existsSync(path.join(release, 'effort.json'))).toBe(false);
    await page.locator('#release-select').selectOption('');
    await expect(page.locator('[data-time-task="PREPARATION"]')).toHaveCount(0);
    expect(fs.readFileSync(file, 'utf8')).toBe(JSON.stringify(ledger, null, 2));
  } finally {
    await closeWindow(app).catch(() => app.process().kill('SIGKILL'));
    await cleanupBroker(path.join(temp, 'run/pty.sock'));
    fs.rmSync(temp, { recursive: true, force: true });
  }
});

test('effort: partial recorded time survives missing roles, task filtering and refresh', async () => {
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'tri-partial-effort-'));
  const home = path.join(temp, 'home'); fs.mkdirSync(home);
  const { project, releaseId } = fixture(home);
  const effortFile = path.join(project, 'changelog', releaseId, 'effort.json');
  const lines = ['odoo-developer', 'odoo-tester', 'orchestrateur'].map(agent => ({ task: 'T01', agent, expected_minutes: 20 }));
  write(effortFile, { schema: 1, release: releaseId, tasks: { T01: 'Factures', T02: 'Maintenance', T03: 'Recette' },
    estimates: [{ revision: 1, at: '2026-09-01T00:00:00Z', lines }], rate_cards: [], entries: [
      { id: 'dev', task: 'T01', agent: 'odoo-developer', status: 'complete', seconds: 1080, suspended_seconds: 28800, tokens: { input_tokens: 100, output_tokens: 20, cached_input_tokens: 50 } },
      { id: 'qa', task: 'T01', agent: 'odoo-tester', status: 'complete', seconds: 300, tokens: null },
      { id: 'coordination', task: 'T01', agent: 'orchestrateur', status: 'running', seconds: null, tokens: null },
    ] });
  const before = fs.readFileSync(effortFile, 'utf8');
  const app = await electron.launch({ args: process.env.TRICORDER_EXECUTABLE ? [] : [root],
    ...(process.env.TRICORDER_EXECUTABLE ? { executablePath: process.env.TRICORDER_EXECUTABLE } : {}),
    env: { ...process.env, HOME: home, TRICORDER_HOME: home,
      TRICORDER_AGENTS_DIR: process.env.TRICORDER_AGENTS_DIR || path.join(os.homedir(), '.odoo19-agents'),
      TRICORDER_STATE_DIR: path.join(temp, 'state'), TRICORDER_RUNTIME_DIR: path.join(temp, 'run') } });
  try {
    const page = await app.firstWindow();
    await expect(page.locator('#release-select')).toHaveValue(releaseId);
    await projectTab(page, 'effort');
    const first = page.locator('[data-time-task="T01"]');
    await expect(first).toContainText('0 h 23 min · à compléter');
    await expect(page.locator('.pilotage-times > tbody > .total-row').first()).toContainText('0 h 23 min · à compléter');
    await first.locator('summary').click();
    await expect(first.locator('[data-agent="odoo-developer"]')).toContainText('0 h 18 min');
    await expect(first.locator('[data-agent="odoo-tester"]')).toContainText('0 h 05 min');
    await expect(first.locator('[data-agent="orchestrateur"]')).toContainText('À compléter');
    await page.locator('[data-action="refresh"]').evaluate(el => el.click());
    await expect(page.locator('#sync-status')).toContainText('À jour');
    await expect(first.locator('details')).toHaveAttribute('open','');
    await expect(first).toContainText('0 h 23 min · à compléter');
    await page.screenshot({path:'test-results/partial-effort.png'});
    expect(fs.readFileSync(effortFile, 'utf8')).toBe(before);
  } finally {
    await closeWindow(app).catch(() => app.process().kill('SIGKILL'));
    await cleanupBroker(path.join(temp, 'run/pty.sock'));
    fs.rmSync(temp, { recursive: true, force: true });
  }
});

test('effort: open release updates task and agent percentages before closure', async () => {
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'tri-live-effort-'));
  const home = path.join(temp, 'home'); fs.mkdirSync(home);
  const { project, releaseId } = fixture(home);
  const effortFile = path.join(project, 'changelog', releaseId, 'effort.json');
  const ledger = { schema: 1, release: releaseId, tasks: { T01: 'Factures', T02: 'Maintenance', T03: 'Recette' },
    estimates: [{ revision: 1, at: '2026-09-01T00:00:00Z', lines: [
      { task: 'T01', agent: 'odoo-developer', expected_minutes: 30 },
      { task: 'T02', agent: 'odoo-tester', expected_minutes: 30 },
      { task: 'T03', agent: 'orchestrateur', expected_minutes: 10 },
    ] }], rate_cards: [], entries: [
      { id: 'dev', task: 'T01', agent: 'odoo-developer', status: 'complete', seconds: 1200, tokens: null },
      { id: 'qa', task: 'T02', agent: 'odoo-tester', status: 'complete', seconds: 600, tokens: null },
    ] };
  write(effortFile, ledger);
  const app = await electron.launch({ args: process.env.TRICORDER_EXECUTABLE ? [] : [root],
    ...(process.env.TRICORDER_EXECUTABLE ? { executablePath: process.env.TRICORDER_EXECUTABLE } : {}),
    env: { ...process.env, HOME: home, TRICORDER_HOME: home,
      TRICORDER_AGENTS_DIR: process.env.TRICORDER_AGENTS_DIR || path.join(os.homedir(), '.odoo19-agents'),
      TRICORDER_STATE_DIR: path.join(temp, 'state'), TRICORDER_RUNTIME_DIR: path.join(temp, 'run') } });
  const errors = [];
  try {
    const page = await app.firstWindow(); page.on('pageerror', e => errors.push(e.message));
    await expect(page.locator('#release-select')).toHaveValue(releaseId);
    await projectTab(page, 'effort');
    const first = page.locator('[data-time-task="T01"]');
    await expect(first).toContainText('0 h 20 min');
    await expect(page.locator('[data-time-task="T02"]')).toContainText('0 h 10 min');
    ledger.entries[1].seconds = 2400; write(effortFile, ledger);
    const expectedFile = fs.readFileSync(effortFile, 'utf8');
    await page.locator('[data-action="refresh"]').evaluate(el => el.click());
    await expect(page.locator('[data-time-task="T02"]')).toContainText('0 h 40 min');
    await expect(page.locator('.total-row').first()).toContainText('1 h 00 min · à compléter');
    await expect(page.locator('.release-summary')).toContainText('Ouverte');
    await page.screenshot({path:'test-results/time-allocation.png'});
    expect(fs.readFileSync(effortFile, 'utf8')).toBe(expectedFile);
    expect(errors).toEqual([]);
  } finally {
    await closeWindow(app).catch(() => app.process().kill('SIGKILL'));
    await cleanupBroker(path.join(temp, 'run/pty.sock')); fs.rmSync(temp, { recursive: true, force: true });
  }
});

test('release context: none, automatic new release, same terminal and persistence', async () => {
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'tri-context-'));
  const home = path.join(temp, 'home'); fs.mkdirSync(home);
  const { project, releaseId } = fixture(home);
  const env = { ...process.env, HOME: home, TRICORDER_HOME: home,
    TRICORDER_AGENTS_DIR: process.env.TRICORDER_AGENTS_DIR || path.join(os.homedir(), '.odoo19-agents'),
    TRICORDER_STATE_DIR: path.join(temp, 'state'), TRICORDER_RUNTIME_DIR: path.join(temp, 'run') };
  const options = { args: process.env.TRICORDER_EXECUTABLE ? [] : [root], env,
    ...(process.env.TRICORDER_EXECUTABLE ? { executablePath: process.env.TRICORDER_EXECUTABLE } : {}) };
  let app = await electron.launch(options);
  const errors = [];
  try {
    let page = await app.firstWindow(); page.on('pageerror', e => errors.push(e.message));
    await app.evaluate(({ BrowserWindow }) => BrowserWindow.getAllWindows()[0].setSize(1000, 700));
    await expect(page.locator('#release-select')).toHaveValue(releaseId);
    await page.locator('#release-select').selectOption('');
    await projectTab(page, 'plan');
    await expect(page.locator('.no-release')).toContainText('Aucune release sélectionnée');
    await page.locator('[data-action="refresh"]').evaluate(el => el.click());
    // The selection was already empty: it cannot prove refresh has finished.
    // Wait for the completed overview before creating a release and refreshing again.
    await expect(page.locator('#sync-status')).toHaveText(/^À jour · /);
    await expect(page.locator('#release-select')).toHaveValue('');
    await expect(page.locator('.project-header [data-action="new-terminal"]')).toHaveCount(0);
    await page.keyboard.press('Control+Shift+T');
    await expect.poll(async () => (await page.evaluate(() => window.tricorder.terminals.list())).length).toBe(1);
    const original = (await page.evaluate(() => window.tricorder.terminals.list()))[0];
    expect(original.release).toBeNull();
    expect(Number.isInteger(original.pid)).toBe(true);
    const newId = '2026-09-12_01_nouvelle-release';
    write(path.join(project, 'changelog', newId, 'README.md'), '<!-- release ouverte -->\n# Nouvelle release\n');
    await page.locator('[data-action="refresh"]').evaluate(el => el.click());
    await expect(page.locator('#release-select')).toHaveValue(newId);
    await expect.poll(async () => (await page.evaluate(() => window.tricorder.terminals.list()))[0].release).toBe(newId);
    const updated = (await page.evaluate(() => window.tricorder.terminals.list()))[0];
    expect(updated.id).toBe(original.id); expect(updated.pid).toBe(original.pid); expect(updated.alive).toBe(true);
    const stored = JSON.parse(fs.readFileSync(path.join(temp, 'state/settings.json'), 'utf8'));
    expect(stored.contexts[project].release).toBe(newId);
    const refused = await page.evaluate(async ({ project, session }) => {
      try { await window.tricorder.terminals.context({ project, session, release: 'missing-release' }); return false; }
      catch { return true; }
    }, { project, session: original.id });
    expect(refused).toBe(true);
    const stale = await page.evaluate(async ({ project, session, release }) => {
      try { await window.tricorder.terminals.context({ project, session, release, expectedRelease: null }); return false; }
      catch { return true; }
    }, { project, session: original.id, release: releaseId });
    expect(stale).toBe(true);
    const foreign = await page.evaluate(async ({ project, session }) => {
      try { await window.tricorder.terminals.context({ project, session, release: null }); return false; }
      catch { return true; }
    }, { project: path.join(home, 'nova-services'), session: original.id });
    expect(foreign).toBe(true);
    await closeWindow(app); app = await electron.launch(options);
    page = await app.firstWindow(); page.on('pageerror', e => errors.push(e.message));
    await expect(page.locator('#release-select')).toHaveValue(newId);
    expect((await page.evaluate(() => window.tricorder.terminals.list()))[0].pid).toBe(original.pid);
    await page.locator('#release-select').selectOption('');
    await projectTab(page, 'terminal');
    await page.locator('[data-action="terminal-context"]').click();
    await expect.poll(async () => (await page.evaluate(() => window.tricorder.terminals.list()))[0].release).toBeNull();
    await page.locator('[data-action="refresh"]').evaluate(el => el.click());
    await expect(page.locator('#release-select')).toHaveValue('');
    await expect(page.locator('#terminal-mismatch')).toHaveCount(0);
    await closeWindow(app); app = await electron.launch(options);
    page = await app.firstWindow(); page.on('pageerror', e => errors.push(e.message));
    await expect(page.locator('#release-select')).toHaveValue('');
    expect((await page.evaluate(() => window.tricorder.terminals.list()))[0].pid).toBe(original.pid);
    await page.screenshot({ path: 'test-results/no-release-terminal.png' });
    expect(errors).toEqual([]);
  } finally {
    await closeWindow(app).catch(() => app.process().kill('SIGKILL'));
    await cleanupBroker(path.join(temp, 'run/pty.sock')); fs.rmSync(temp, { recursive: true, force: true });
  }
});

test('flow starts: delayed terminal cannot hijack navigation, ambiguous adoption stays explicit', async () => {
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'tri-flow-starts-'));
  const home = path.join(temp, 'home'); fs.mkdirSync(home);
  const { project, releaseId } = fixture(home);
  const app = await electron.launch({ args: process.env.TRICORDER_EXECUTABLE ? [] : [root],
    ...(process.env.TRICORDER_EXECUTABLE ? { executablePath: process.env.TRICORDER_EXECUTABLE } : {}),
    env: { ...process.env, HOME: home, TRICORDER_HOME: home,
      TRICORDER_AGENTS_DIR: process.env.TRICORDER_AGENTS_DIR || path.join(os.homedir(), '.odoo19-agents'),
      TRICORDER_STATE_DIR: path.join(temp, 'state'), TRICORDER_RUNTIME_DIR: path.join(temp, 'run') } });
  const errors = [];
  try {
    const page = await app.firstWindow(); page.on('pageerror', e => errors.push(e.message));
    await app.evaluate(({ BrowserWindow }) => BrowserWindow.getAllWindows()[0].setSize(1000, 700));
    await expect(page.locator('#release-select')).toHaveValue(releaseId);
    await page.locator('#release-select').selectOption('');
    await projectTab(page, 'plan');
    await expect(page.locator('.no-release')).toBeVisible();
    // Deterministic pause, not a timing-dependent sleep: user leaves during creation.
    await app.evaluate(({ ipcMain }) => {
      const original = ipcMain._invokeHandlers.get('terminal:create');
      ipcMain.removeHandler('terminal:create');
      ipcMain.handle('terminal:create', async (...args) => {
        await new Promise(resolve => { globalThis.finishTerminalCreation = resolve; });
        return original(...args);
      });
      globalThis.originalTerminalCreate = original;
    });
    await page.keyboard.press('Control+Shift+T');
    await expect.poll(() => app.evaluate(() => typeof globalThis.finishTerminalCreation)).toBe('function');
    await page.locator('[data-project]').filter({ hasText: 'nova-services' }).click();
    const nova = path.join(home, 'nova-services');
    const expectNovaEmptyTerminal = async () => {
      await expect(page.locator('#project-title')).toHaveText('nova-services');
      await expect(page.locator(`[data-project="${nova}"]`)).toHaveAttribute('aria-current', 'page');
      await expect(page.locator('.no-release')).toBeVisible();
      await expect(page.locator('#terminal-workspace')).toBeVisible();
      await expect(page.locator('#terminal-empty')).toBeVisible();
      await expect(page.locator('#terminal-empty')).toContainText('Aucun terminal ouvert');
      await expect(page.locator('#terminal-hosts')).toBeHidden();
      await expect(page.locator('.terminal-host:visible, .terminal-tab')).toHaveCount(0);
      expect((await page.evaluate(() => window.tricorder.terminals.list())).filter(s => s.project === nova)).toHaveLength(0);
    };
    // Ctrl+Shift+T deliberately keeps the terminal panel visible across projects.
    // Nova must already be empty before the former project's IPC reply arrives.
    await expectNovaEmptyTerminal();
    const novaContent = await page.locator('#content').innerText();
    expect(await page.evaluate(() => window.tricorder.terminals.list())).toHaveLength(0);
    await app.evaluate(({ ipcMain }) => {
      ipcMain.removeHandler('terminal:create'); ipcMain.handle('terminal:create', globalThis.originalTerminalCreate);
      globalThis.finishTerminalCreation();
    });
    await expect(page.locator('#session-count')).toHaveCount(0);
    await expect.poll(() => page.evaluate(async () => (await window.tricorder.terminals.list()).length)).toBe(1);
    // The late reply must neither switch Nova's screen nor attach Orbital's PTY.
    await expectNovaEmptyTerminal();
    expect(await page.locator('#content').innerText()).toBe(novaContent);
    const first = (await page.evaluate(() => window.tricorder.terminals.list()))[0];
    expect(first.project).toBe(project); expect(first.release).toBeNull(); expect(first.task).toBeNull();
    await page.locator('[data-project]').filter({ hasText: 'orbital-industries' }).click();
    await expect(page.locator('#release-select')).toHaveValue('');
    // Two ordinary conversations and an Express conversation: never guess a creator.
    await page.evaluate(async project => {
      await window.tricorder.terminals.create({ project, release: null });
      await window.tricorder.terminals.create({ project, release: null, scopeMode: 'express' });
    }, project);
    const newId = '2026-09-12_01_ambiguite';
    write(path.join(project, 'changelog', newId, 'README.md'), '<!-- release ouverte -->\n# Nouvelle release\n');
    await page.locator('[data-action="refresh"]').evaluate(el => el.click());
    await expect(page.locator('#release-select')).toHaveValue(newId);
    const unchanged = await page.evaluate(() => window.tricorder.terminals.list());
    expect(unchanged).toHaveLength(3);
    expect(unchanged.every(s => s.release === null)).toBe(true);
    await expect(page.locator('#toast')).toContainText('aucun terminal réaffecté automatiquement');
    await projectTab(page, 'terminal');
    await projectTab(page, 'terminal');
    await page.locator('[data-action="terminal-context"]').click();
    await expect.poll(async () => (await page.evaluate(() => window.tricorder.terminals.list())).filter(s => s.release === newId).length).toBe(1);
    const assigned = await page.evaluate(() => window.tricorder.terminals.list());
    expect(assigned.find(s => s.id === first.id).release).toBe(newId);
    expect(assigned.find(s => s.id === first.id).pid).toBe(first.pid);
    expect(assigned.find(s => s.scopeMode === 'express').release).toBeNull();
    // A late response for the former project must not replace the current screen.
    await projectTab(page, 'plan');
    await app.evaluate(({ ipcMain }, delayedProject) => {
      const original = ipcMain._invokeHandlers.get('project');
      ipcMain.removeHandler('project');
      ipcMain.handle('project', async (...args) => {
        if (args[1] === delayedProject) await new Promise(resolve => { globalThis.finishProjectRead = resolve; });
        return original(...args);
      });
      globalThis.originalProjectRead = original;
    }, project);
    await page.locator('#release-select').selectOption(releaseId);
    await expect.poll(() => app.evaluate(() => typeof globalThis.finishProjectRead)).toBe('function');
    await page.locator('[data-project]').filter({ hasText: 'nova-services' }).click();
    await expect(page.locator('.no-release')).toBeVisible();
    await app.evaluate(({ ipcMain }) => {
      ipcMain.removeHandler('project'); ipcMain.handle('project', globalThis.originalProjectRead);
      globalThis.finishProjectRead();
    });
    await page.locator('[data-action="refresh"]').evaluate(el => el.click());
    await expect(page.locator('.project-item.selected')).toContainText('nova-services');
    await expect(page.locator('.no-release')).toBeVisible();
    const stored = JSON.parse(fs.readFileSync(path.join(temp, 'state/settings.json'), 'utf8'));
    expect(stored.contexts[project].release).toBe(newId);
    expect(errors).toEqual([]);
  } finally {
    await closeWindow(app).catch(() => app.process().kill('SIGKILL'));
    await cleanupBroker(path.join(temp, 'run/pty.sock')); fs.rmSync(temp, { recursive: true, force: true });
  }
});

test('Markdown preview: readable safe content and recovery from a project read error', async () => {
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'tri-markdown-'));
  const home = path.join(temp, 'home'); fs.mkdirSync(home);
  const { project, releaseId } = fixture(home);
  const source = '<!-- release ouverte -->\n# Guide lisible\n\n## Résultat\n\nDu **gras**, de l’*italique* et du `code`.\n\n- Premier point\n- Second point\n\n- [x] Accepté\n\n| Tâche | Résultat |\n| --- | --- |\n| T01 | Validé |\n\n> Une remarque utile.\n\n```js\nconst ok = true;\n```\n\n![tracking](https://invalid.example.test/pixel.png)\n<script>window.INJECTED = true</script>\n<button data-action="new-terminal">Non actif</button>\n<a href="javascript:alert(1)">Lien dangereux</a>\n';
  write(path.join(project, 'changelog', releaseId, 'README.md'), source);
  const app = await electron.launch({ args: process.env.TRICORDER_EXECUTABLE ? [] : [root],
    ...(process.env.TRICORDER_EXECUTABLE ? { executablePath: process.env.TRICORDER_EXECUTABLE } : {}),
    env: { ...process.env, HOME: home, TRICORDER_HOME: home,
      TRICORDER_AGENTS_DIR: process.env.TRICORDER_AGENTS_DIR || path.join(os.homedir(), '.odoo19-agents'),
      TRICORDER_STATE_DIR: path.join(temp, 'state'), TRICORDER_RUNTIME_DIR: path.join(temp, 'run') } });
  const errors = [], external = [];
  try {
    const page = await app.firstWindow(); page.on('pageerror', e => errors.push(e.message));
    page.on('request', r => { if (/^https?:/.test(r.url())) external.push(r.url()); });
    await expect(page.locator('#release-select')).toHaveValue(releaseId);
    await projectTab(page, 'plan');
    await page.locator('.release-links [data-document]').click();
    await expect(page.locator('.markdown-preview h1')).toHaveText('Guide lisible');
    await expect(page.locator('.markdown-preview strong')).toHaveText('gras');
    await expect(page.locator('.markdown-preview table td')).toHaveCount(2);
    await expect(page.locator('.markdown-preview input')).toBeChecked();
    await expect(page.locator('.markdown-preview input')).toBeDisabled();
    await expect(page.locator('.markdown-preview script, .markdown-preview img, .markdown-preview button, .markdown-preview [href], .markdown-preview [data-action]')).toHaveCount(0);
    expect(await page.evaluate(() => window.INJECTED)).toBeUndefined();
    await page.screenshot({ path: 'test-results/markdown-preview.png' });
    await page.locator('.markdown-source summary').click();
    await expect(page.locator('.markdown-source pre')).toHaveText(source);
    await page.locator('[data-action="modal-close"]').click();
    await projectView(page, 'documents');
    await page.locator('[data-files="changelog"]').first().click();
    await page.locator(`[data-files="changelog/${releaseId}"]`).click();
    await page.locator(`[data-preview="changelog/${releaseId}/README.md"]`).click();
    await expect(page.locator('.markdown-preview h1')).toHaveText('Guide lisible');
    await page.locator('[data-action="modal-close"]').click();
    await projectTab(page, 'plan');
    await app.evaluate(({ ipcMain }) => {
      globalThis.savedProjectHandler = ipcMain._invokeHandlers.get('project');
      ipcMain.removeHandler('project'); ipcMain.handle('project', () => { throw new Error('synthetic project read failure'); });
    });
    await page.locator('#release-select').selectOption('');
    await expect(page.locator('#content')).toContainText('Lecture impossible');
    await expect(page.locator('.quality-panel')).toHaveCount(0);
    await app.evaluate(({ ipcMain }) => { ipcMain.removeHandler('project'); ipcMain.handle('project', globalThis.savedProjectHandler); });
    await page.locator('[data-action="refresh"]').evaluate(el => el.click());
    await expect(page.locator('#content')).not.toContainText('Lecture impossible');
    expect(errors).toEqual([]); expect(external).toEqual([]);
  } finally {
    await closeWindow(app).catch(() => app.process().kill('SIGKILL'));
    await cleanupBroker(path.join(temp, 'run/pty.sock')); fs.rmSync(temp, { recursive: true, force: true });
  }
});

test('email removed: no UI or API, old private records preserved, project still usable', async () => {
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'tri-no-mail-'));
  const home = path.join(temp, 'home'); fs.mkdirSync(home);
  const { project, releaseId } = fixture(home);
  const privateState = path.join(temp, 'delivery');
  const key = require('node:crypto').createHash('sha256').update(JSON.stringify(project)).digest('hex');
  const config = path.join(privateState, key, 'config.json');
  const draft = path.join(privateState, key, 'old-draft.json');
  write(config, { enabled: true, transport: 'gmail-smtp', sender: 'synthetic@example.test' });
  write(draft, { status: 'draft', body: 'Ancien brouillon à préserver' });
  const before = [config, draft].map(file => fs.readFileSync(file, 'utf8'));
  const env = { ...process.env, HOME: home, TRICORDER_HOME: home,
    TRICORDER_AGENTS_DIR: process.env.TRICORDER_AGENTS_DIR || path.join(os.homedir(), '.odoo19-agents'),
    TRICORDER_STATE_DIR: path.join(temp, 'state'), TRICORDER_RUNTIME_DIR: path.join(temp, 'run'),
    ODOO_DELIVERY_STATE_DIR: privateState };
  const app = await electron.launch({ args: process.env.TRICORDER_EXECUTABLE ? [] : [root], env,
    ...(process.env.TRICORDER_EXECUTABLE ? { executablePath: process.env.TRICORDER_EXECUTABLE } : {}) });
  const errors = [];
  try {
    const page = await app.firstWindow(); page.on('pageerror', error => errors.push(error.message));
    await expect(page.locator('#release-select')).toHaveValue(releaseId);
    await projectTab(page, 'plan');
    await expect(page.locator('.delivery-panel')).toHaveCount(0);
    await expect(page.getByText('Email de clôture', { exact: true })).toHaveCount(0);
    const snapshot = await page.evaluate(async p => ({
      data: await window.tricorder.project(p),
      api: Object.keys(window.tricorder.cockpit),
    }), project);
    expect(snapshot.data).not.toHaveProperty('delivery');
    expect(snapshot.data).not.toHaveProperty('deliveryConfig');
    for (const name of ['deliveryConfigure', 'deliveryEdit', 'deliveryAttachments', 'deliveryConnectSmtp', 'send'])
      expect(snapshot.api).not.toContain(name);
    await projectView(page, 'documents');
    await expect(page.locator('[data-view="communication"]')).toHaveCount(0);
    await expect(page.locator('#mail-sender')).toHaveCount(0);
    await expect(page.locator('[data-cockpit="delivery-connect-smtp"]')).toHaveCount(0);
    await expect(page.locator('.project-resources [data-view]')).toHaveCount(3);
    await page.locator('[data-action="refresh"]').evaluate(el => el.click());
    await projectTab(page, 'plan');
    await expect(page.locator('#release-select')).toHaveValue(releaseId);
    await expect(page.locator('.delivery-panel')).toHaveCount(0);
    await page.screenshot({ path: 'test-results/email-removed.png' });
    expect([config, draft].map(file => fs.readFileSync(file, 'utf8'))).toEqual(before);
    expect(errors).toEqual([]);
  } finally {
    await closeWindow(app).catch(() => app.process().kill('SIGKILL'));
    await cleanupBroker(path.join(temp, 'run/pty.sock'));
    fs.rmSync(temp, { recursive: true, force: true });
  }
});

test('desktop: projects, proof status, sources, real terminal and persistence', async () => {
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'tri-ui-'));
  const home = path.join(temp, 'home'); fs.mkdirSync(home);
  const { project } = fixture(home);
  const env = { ...process.env, HOME: home, HISTFILE: path.join(temp, 'shell-history'),
    TRICORDER_AGENTS_DIR: process.env.TRICORDER_AGENTS_DIR || path.join(os.homedir(), '.odoo19-agents'),
    TRICORDER_HOME: home, TRICORDER_STATE_DIR: path.join(temp, 'state'), TRICORDER_RUNTIME_DIR: path.join(temp, 'run') };
  const launchOptions = { args: process.env.TRICORDER_EXECUTABLE ? [] : [root], env,
    ...(process.env.TRICORDER_EXECUTABLE ? { executablePath: process.env.TRICORDER_EXECUTABLE } : {}) };
  let app;
  const errors = [];
  try {
    app = await electron.launch(launchOptions);
    await app.firstWindow();
    await app.evaluate(({ Menu }) => {
      const collect = menu => menu.items.flatMap(item => [item.role, ...(item.submenu ? collect(item.submenu) : [])]);
      if (collect(Menu.getApplicationMenu()).includes('pasteandmatchstyle')) throw new Error('Conflicting native paste accelerator');
    });
    let page = await app.firstWindow();
    page.on('pageerror', error => errors.push(error.message));
    await expect(page.locator('#project-title')).toHaveText('orbital-industries');
    await expect(page.locator('#release-select')).toHaveValue('2026-09-11_01_facturation-et-maintenance');
    await projectTab(page, 'plan');
    await page.locator('[data-plan-mode="list"]').click();
    await expect(page.locator('.task-card')).toHaveCount(3);
    await expect(page.locator('[data-task="T01"]')).toContainText('Tests à actualiser');
    await page.locator('[data-task="T02"]').click();
    await expect(page.locator('#task-modal')).toBeVisible();
    await page.locator('[data-board-close]').click();
    await page.screenshot({ path: 'test-results/plan.png' });
    await projectView(page, 'sources');
    await expect(page.locator('#content')).toContainText('Aucune substitution par une autre série');
    await projectView(page, 'environments');
    await page.locator('[data-environment="staging"]').click();
    await page.keyboard.press('Control+Shift+T');
    await expect(page.locator('.terminal-host')).toHaveCount(1);
    const first = await page.evaluate(async () => (await window.tricorder.terminals.list())[0]);
    expect(first.environment).toBe('staging');
    expect(first.project).toBe(project);
    await page.locator('.xterm-helper-textarea').focus();
    await page.keyboard.type("printf 'TRICORDER-%s\\n' 'READY'");
    await page.keyboard.press('Enter');
    await expect(page.locator('.xterm-screen')).toContainText('TRICORDER-READY');
    // Isolate clipboard tests from the user's actual desktop clipboard.
    await app.evaluate(({ clipboard }) => {
      let value = '';
      clipboard.readText = () => value;
      clipboard.writeText = text => { value = text; };
    });
    await page.evaluate(() => window.tricorder.clipboard.write("printf 'PASTE-%s\\n' 'OK'"));
    // Untrusted DOM event exercises our handler without allowing Chromium to
    // read the operating-system clipboard as a native default action.
    await page.locator('.xterm-helper-textarea').dispatchEvent('keydown', { key: 'V', code: 'KeyV', ctrlKey: true, shiftKey: true, bubbles: true, cancelable: true });
    await expect(page.locator('.xterm-screen')).toContainText('PASTE-%s');
    await page.keyboard.press('Enter');
    await expect(page.locator('.xterm-screen')).toContainText('PASTE-OK');
    expect((await page.locator('.xterm-screen').innerText()).match(/PASTE-OK/g)).toHaveLength(1);
    await page.locator('#environment-select').selectOption('production');
    expect((await page.evaluate(async () => (await window.tricorder.terminals.list())[0])).environment).toBe('staging');
    await page.screenshot({ path: 'test-results/terminal.png' });
    await projectView(page, 'documents');
    await page.locator('[data-files=".odoo-agents"]').first().click();
    await page.locator('[data-preview=".odoo-agents/JOURNAL.md"]').click();
    await expect(page.locator('.document-text')).toContainText('Le suivi des missions');
    await page.locator('[data-action="modal-close"]').click();
    if (!(await page.locator('.sidebar-tools').evaluate(el => el.open))) await page.locator('.sidebar-tools > summary').click();
    await page.locator('[data-action="about"]').click();
    await expect(page.locator('#modal')).toContainText('github.com/le-goff-benoit/odoo-crew');
    await expect(page.locator('#modal')).toContainText('github.com/le-goff-benoit/odoo-tricorder');
    await app.evaluate(({ shell }) => { globalThis.openedLink = null; shell.openExternal = async url => { globalThis.openedLink = url; }; });
    await page.locator('#modal [data-action="agents-link"]').click();
    expect(await app.evaluate(() => globalThis.openedLink)).toBe('https://github.com/le-goff-benoit/odoo-crew');
    await page.locator('#modal [data-action="repo-link"]').click();
    expect(await app.evaluate(() => globalThis.openedLink)).toBe('https://github.com/le-goff-benoit/odoo-tricorder');
    await page.locator('[data-action="modal-close"]').click();
    await closeWindow(app);
    app = null;
    app = await electron.launch(launchOptions);
    page = await app.firstWindow();
    page.on('pageerror', error => errors.push(error.message));
    await projectTab(page, 'terminal');
    await expect(page.locator('.xterm-screen')).toContainText('TRICORDER-READY');
    const after = await page.evaluate(async () => (await window.tricorder.terminals.list())[0]);
    expect(after.pid).toBe(first.pid);
    expect(after.environment).toBe('staging');
    await expect(page.locator('#environment-select')).toHaveValue('production');
    const originalSize = await app.evaluate(({ BrowserWindow }) => BrowserWindow.getAllWindows()[0].getSize());
    await app.evaluate(({ BrowserWindow }) => BrowserWindow.getAllWindows()[0].setSize(1050, 700));
    await expect(page.locator('.xterm-helper-textarea')).toBeAttached();
    await page.screenshot({ path: 'test-results/compact.png' });
    await app.evaluate(({ BrowserWindow }, size) => BrowserWindow.getAllWindows()[0].setSize(...size), originalSize);
    expect(errors).toEqual([]);
  } finally {
    if (app) { await closeWindow(app).catch(() => { app.process().kill('SIGKILL'); }); }
    await cleanupBroker(path.join(temp, 'run/pty.sock'));
    fs.rmSync(temp, { recursive: true, force: true });
  }
});

test('lifecycle: releases, remembered tasks, terminal scope, attention and rapid navigation', async () => {
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'tri-lifecycle-'));
  const home = path.join(temp, 'home'); fs.mkdirSync(home);
  const { project, releaseId } = fixture(home);
  const historical = '2026-09-10_01_historique';
  const emptyRelease = '2026-09-09_01_sans-plan';
  write(path.join(project, 'changelog', historical, 'README.md'), '# Historique\n| 1 | Livrer le premier point | fait |\n| 2 | Point bloqué | bloqué |');
  write(path.join(project, 'changelog', emptyRelease, 'README.md'), '# Bilan de livraison\nVersion livrée : 1.0.');
  write(path.join(project, '.odoo-agents/flows/express-caption.json'), {
    kind: 'express', status: 'complete', graph_snapshot: { nodes: {
      express_qa: { description: 'Contrôles ciblés' }, task_done: { description: 'Terminée' },
    } }, events: [{ node: 'express_qa', outcome: 'pass', evidence: ['Contrôle ciblé synthétique'] },
      { node: 'task_done', outcome: 'done' }], updated_at: '2026-09-11T09:00:00Z',
  });
  const env = { ...process.env, HOME: home, HISTFILE: path.join(temp, 'history'),
    TRICORDER_AGENTS_DIR: process.env.TRICORDER_AGENTS_DIR || path.join(os.homedir(), '.odoo19-agents'),
    TRICORDER_HOME: home, TRICORDER_STATE_DIR: path.join(temp, 'state'), TRICORDER_RUNTIME_DIR: path.join(temp, 'run') };
  const launch = { args: process.env.TRICORDER_EXECUTABLE ? [] : [root], env,
    ...(process.env.TRICORDER_EXECUTABLE ? { executablePath: process.env.TRICORDER_EXECUTABLE } : {}) };
  let app;
  const errors = [];
  try {
    app = await electron.launch(launch);
    let page = await app.firstWindow(); page.on('pageerror', e => errors.push(e.message));
    await expect(page.locator('#release-select')).toHaveValue(releaseId);
    await expect(page.locator('.brand-name')).toHaveText('Tricorder');
    await expect(page.locator('.topbar')).not.toContainText(/poste local/i);
    await projectTab(page, 'express');
    await expect(page.locator('.express-card')).toHaveCount(1);
    await expect(page.locator('.express-card')).not.toContainText('Hors release');
    await expect(page.locator('.express-card')).toContainText('Terminée');
    await expect(page.locator('.express-card')).toContainText('Tests réussis');
    await expect(page.locator('#context-bar')).toBeHidden();
    await projectTab(page, 'plan');
    await expect(page.locator('#context-bar')).toBeVisible();
    await expect(page.locator('.project-header [data-action="new-terminal"]')).toHaveCount(0);
    await projectTab(page, 'terminal');
    await page.locator('#terminal-tabs [data-action="new-terminal"]').click();
    await expect(page.locator('.terminal-host')).toHaveCount(1);
    const terminal = await page.evaluate(async () => (await window.tricorder.terminals.list())[0]);
    await page.locator('#release-select').selectOption(historical);
    await projectTab(page, 'terminal');
    await expect(page.locator('#terminal-mismatch')).toBeVisible();
    await expect(page.locator('#terminal-context')).not.toContainText('ouvert ');
    await expect(page.locator('#terminal-context [data-action="terminal-context"]')).toBeVisible();
    await expect(page.locator('#environment-select').locator('..')).toContainText('Environnement');
    await expect(page.locator('#environment-select').locator('..')).not.toContainText(/repère/i);
    await projectTab(page, 'plan');
    await expect(page.locator('.release-state')).toContainText('Close');
    await page.locator('[data-plan-mode="list"]').click();
    await expect(page.locator('.task-card')).toHaveCount(2);
    await expect(page.locator('.task-card[data-task="P1"]')).toContainText('validation non vérifiée');
    await projectTab(page, 'terminal');
    await expect(page.locator('#release-select')).toHaveValue(historical);
    expect((await page.evaluate(() => window.tricorder.terminals.list())).length).toBe(1);
    await expect(page.locator('#terminal-mismatch')).toContainText('Terminal partagé du projet');
    await projectTab(page, 'plan');
    await page.locator('#release-select').selectOption(releaseId);
    await page.locator('#release-select').selectOption(historical);
    await projectTab(page, 'terminal');
    await page.locator('[data-follow-session]').click();
    await expect(page.locator('#release-select')).toHaveValue(releaseId);
    await expect(page.locator('#terminal-mismatch')).toHaveCount(0);
    // Invalid associations fail before opening a file picker or persisting metadata.
    const rejection = await page.evaluate(async ({ project, releaseId, terminal }) => {
      try { await window.tricorder.cockpit.bind({ project, release: releaseId, task: 'T03', flow: '.odoo-agents/flows/maintenance.json', terminal: terminal.id, provider: 'codex' }); }
      catch (e) { return e.message; }
    }, { project, releaseId, terminal });
    expect(rejection).toContain('non associé à cette tâche');
    // One conversation/terminal may span several tasks; its opening scope is not a lock.
    const prepared = await page.evaluate(({ project, releaseId, terminal }) => window.tricorder.cockpit.prepareClaude({ project, release: releaseId, task: 'T03', terminal: terminal.id }), { project, releaseId, terminal });
    expect(prepared.command).toContain('claude --settings');
    const before = await page.evaluate(async () => (await window.tricorder.terminals.list())[0]);
    expect(before.pid).toBe(terminal.pid); expect(before.task).toBeNull();
    await page.locator('#release-select').selectOption(emptyRelease);
    await projectTab(page, 'plan');
    await expect(page.locator('#content')).toContainText('Aucune tâche structurée');
    await page.locator('.release-links [data-document]').click();
    await expect(page.locator('#modal')).toContainText('Bilan de livraison');
    await page.locator('[data-action="modal-close"]').click();
    await expect(page.locator('[data-action="attention"]')).toHaveCount(0);
    await page.locator('#release-select').selectOption(historical);
    await expect(page.locator('#release-select')).toHaveValue(historical);
    await page.locator('[data-project]').filter({ hasText: 'nova-services' }).click();
    await page.locator('[data-project]').filter({ hasText: 'orbital-industries' }).click();
    await expect(page.locator('[data-action="add"]')).toHaveCount(0);
    const projectSearch = page.getByLabel('Rechercher un projet', { exact: true });
    await expect(projectSearch).toBeVisible();
    await projectSearch.fill('nova');
    await expect(page.locator('.project-item[data-project]')).toHaveCount(1);
    await expect(page.locator('.project-item[data-project]')).toContainText('nova-services');
    await expect(projectSearch).toBeFocused();
    await projectSearch.fill('');
    await expect(page.locator('.project-item[data-project]')).toHaveCount(3);
    // Two navigation events in the same turn: only the latest response may win.
    await page.evaluate(([first, last]) => {
      const select = document.querySelector('#release-select');
      select.value = first; select.dispatchEvent(new Event('change', { bubbles: true }));
      select.value = last; select.dispatchEvent(new Event('change', { bubbles: true }));
    }, [releaseId, historical]);
    await expect(page.locator('#release-select')).toHaveValue(historical);
    await page.screenshot({ path: 'test-results/lifecycle-plan.png' });
    await closeWindow(app); app = null;
    app = await electron.launch(launch); page = await app.firstWindow();
    await expect(page.locator('#release-select')).toHaveValue(historical);
    await projectTab(page, 'terminal');
    await expect(page.locator('#terminal-mismatch')).toBeVisible();
    await projectView(page, 'documents');
    await page.screenshot({ path: 'test-results/project-resources.png' });
    await projectTab(page, 'express');
    await expect(page.locator('.express-card')).toHaveCount(1);
    await page.screenshot({ path: 'test-results/express.png' });
    await page.keyboard.press('Control+Shift+T');
    await expect(page.locator('.terminal-host')).toHaveCount(2);
    const allTerminals = await page.evaluate(() => window.tricorder.terminals.list());
    const expressTerminal = allTerminals.find(t => t.id !== terminal.id);
    expect(expressTerminal.release).toBeNull();
    expect(expressTerminal.task).toBeNull();
    expect(errors).toEqual([]);
  } finally {
    if (app) await closeWindow(app).catch(() => app.process().kill('SIGKILL'));
    await cleanupBroker(path.join(temp, 'run/pty.sock'));
    fs.rmSync(temp, { recursive: true, force: true });
  }
});

test('real project: read-only release/task/mission screens', async () => {
  test.skip(!process.env.TRICORDER_REAL_PROJECT, 'Opt-in local uniquement ; aucune donnée client dans les fixtures CI');
  test.setTimeout(120000);
  const project = fs.realpathSync(process.env.TRICORDER_REAL_PROJECT);
  const releaseId = process.env.TRICORDER_REAL_RELEASE;
  if (!releaseId || !/^[\w-]+$/.test(releaseId)) throw new Error('Release réelle explicite requise');
  const { createHash } = require('node:crypto');
  const protectedFiles = [];
  function collect(folder) {
    for (const item of fs.readdirSync(folder, { withFileTypes: true })) {
      if (item.isSymbolicLink()) continue;
      const file = path.join(folder, item.name);
      if (item.isDirectory()) collect(file);
      else if (/\.(md|json)$/.test(item.name)) protectedFiles.push(file);
    }
  }
  collect(path.join(project, 'changelog', releaseId));
  const effortRelease = process.env.TRICORDER_REAL_EFFORT_RELEASE;
  if (effortRelease) {
    if (!/^[\w-]+$/.test(effortRelease)) throw new Error('Release de temps explicite requise');
    collect(path.join(project, 'changelog', effortRelease));
  }
  const digest = () => protectedFiles.map(file => createHash('sha256').update(fs.readFileSync(file)).digest('hex'));
  const before = digest();
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'tri-real-readonly-'));
  const home = path.join(temp, 'home'); fs.mkdirSync(home);
  write(path.join(temp, 'state/settings.json'), { extras: [project], activeProject: project, contexts: { [project]: { release: releaseId } } });
  let app;
  const errors = [];
  try {
    app = await electron.launch({ args: process.env.TRICORDER_EXECUTABLE ? [] : [root],
      ...(process.env.TRICORDER_EXECUTABLE ? { executablePath: process.env.TRICORDER_EXECUTABLE } : {}),
      env: { ...process.env, HOME: home, HISTFILE: path.join(temp, 'history'),
        TRICORDER_AGENTS_DIR: process.env.TRICORDER_AGENTS_DIR || path.join(os.homedir(), '.odoo19-agents'),
        TRICORDER_HOME: home, TRICORDER_STATE_DIR: path.join(temp, 'state'), TRICORDER_RUNTIME_DIR: path.join(temp, 'run') } });
    const page = await app.firstWindow(); page.on('pageerror', e => errors.push(e.message));
    await expect(page.locator('#release-select')).toHaveValue(releaseId);
    await projectTab(page, 'plan');
    await expect(page.locator('.release-state')).toContainText('Close');
    await expect(page.locator('.task-card')).toHaveCount(5);
    await page.screenshot({ path: 'test-results/real-neca-plan.png' });
    await page.locator('[data-task="T01"]').click();
    await expect(page.locator('#task-modal')).toContainText('Critères d’acceptation');
    await expect(page.locator('#task-modal')).toContainText('Réception');
    await page.screenshot({ path: 'test-results/real-neca-task-modal.png' });
    await page.locator('[data-board-close]').click();
    await kanbanMode(page);
    await expect(page.locator('.kanban-card')).toHaveCount(5);
    await page.screenshot({ path: 'test-results/real-neca-kanban.png' });
    await projectTab(page, 'work');
    await expect(page.locator('#content')).toContainText('Historique de mission');
    await page.screenshot({ path: 'test-results/real-neca-agents.png' });
    await projectTab(page, 'effort');
    expect(await page.locator('#content .table-scroll').first().locator('tbody tr').count()).toBeGreaterThanOrEqual(5);
    await expect(page.locator('#content .metric strong').first()).toContainText(' h ');
    const actualHeadline = await page.locator('#content .metric strong').nth(1).innerText();
    expect(actualHeadline === 'Non mesuré' || actualHeadline.includes(' h ')).toBe(true);
    await page.screenshot({ path: 'test-results/real-neca-effort.png' });
    if (effortRelease) {
      await page.locator('#release-select').selectOption(effortRelease);
      await expect(page.locator('.metric').nth(1)).toContainText('partiel');
      await expect(page.locator('.metric').nth(1).locator('strong')).toHaveText('2 h 19 min');
      await expect(page.locator('#content .table-scroll').first().locator('tbody tr').filter({ hasText: 'T01' }).locator('td').nth(3)).toContainText('0 h 23 min');
      await expect(page.locator('#content .table-scroll').first().locator('tbody tr').filter({ hasText: 'T03' }).locator('td').nth(3)).toContainText('0 h 58 min');
      const t02 = page.locator('#content .table-scroll').first().locator('tbody tr').filter({ hasText: 'T02' });
      await t02.locator('.agent-breakdown summary').click();
      await expect(t02.locator('[data-agent="odoo-tester"]')).toContainText('Aucun relevé enregistré');
      await expect(page.locator('.open-timers')).toHaveCount(0);
      await page.screenshot({ path: 'test-results/real-neca-partial-effort.png' });
      await page.locator('#release-select').selectOption(releaseId);
    }
    await app.evaluate(({ BrowserWindow }) => BrowserWindow.getAllWindows()[0].setSize(1050, 700));
    await projectTab(page, 'plan');
    await page.screenshot({ path: 'test-results/real-neca-compact.png' });
    const other = await page.locator('#release-select option').first().getAttribute('value');
    await page.locator('#release-select').selectOption(other);
    await projectTab(page, 'plan');
    await page.locator('#release-select').selectOption(releaseId);
    expect(await page.evaluate(() => window.tricorder.terminals.list())).toEqual([]);
    expect(errors).toEqual([]);
    expect(digest()).toEqual(before);
  } finally {
    if (app) await closeWindow(app).catch(() => app.process().kill('SIGKILL'));
    await cleanupBroker(path.join(temp, 'run/pty.sock'));
    fs.rmSync(temp, { recursive: true, force: true });
  }
});

test('roadmap: observations, human alert, measures, files, graph, preparation and preferences', async () => {
  test.setTimeout(120000);
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'tri-roadmap-'));
  const home = path.join(temp, 'home'); fs.mkdirSync(home);
  const { project, releaseId } = fixture(home);
  write(path.join(project, 'inbox/ticket.eml'), 'Subject: Demande synthétique\n\nÀ examiner.');
  write(path.join(project, 'changelog', releaseId, 'junit-targeted.xml'), '<testsuite tests="12" failures="0" errors="0" skipped="2"><properties><property name="odoo.task" value="T02"/></properties></testsuite>');
  const native = path.join(temp, 'session.jsonl');
  const date = seconds => new Date(Date.now() - 60000 + seconds * 1000).toISOString();
  const rows = [
    { type: 'session_meta', timestamp: date(0), payload: { id: 'synthetic-thread', timestamp: date(0) } },
    { type: 'turn_context', timestamp: date(0), payload: { turn_id: 'turn1', model: 'synthetic-model' } },
    { type: 'event_msg', timestamp: date(0), payload: { type: 'task_started', turn_id: 'turn1' } },
    { type: 'token_usage_record', timestamp: date(10), payload: { thread_id: 'synthetic-thread', response_id: 'response1', thread_token_usage: { input_tokens: 100, cached_input_tokens: 0, cache_write_input_tokens: 0, output_tokens: 40, total_tokens: 140 } } },
    { type: 'event_msg', timestamp: date(20), payload: { type: 'task_complete', turn_id: 'turn1', duration_ms: 20000 } },
    { type: 'event_msg', timestamp: date(21), payload: { type: 'exec_approval_request', command: 'DO-NOT-EXPOSE-PRIVATE' } },
  ];
  write(native, rows.map(r => JSON.stringify(r)).join('\n') + '\n');
  const env = { ...process.env, HOME: home, HISTFILE: path.join(temp, 'shell-history'),
    TRICORDER_AGENTS_DIR: process.env.TRICORDER_AGENTS_DIR || path.join(os.homedir(), '.odoo19-agents'),
    TRICORDER_HOME: home, TRICORDER_STATE_DIR: path.join(temp, 'state'), TRICORDER_RUNTIME_DIR: path.join(temp, 'run') };
  const launchOptions = { args: process.env.TRICORDER_EXECUTABLE ? [] : [root], env,
    ...(process.env.TRICORDER_EXECUTABLE ? { executablePath: process.env.TRICORDER_EXECUTABLE } : {}) };
  let app;
  const errors = [];
  try {
    app = await electron.launch(launchOptions);
    const page = await app.firstWindow();
    page.on('pageerror', error => errors.push(error.message));
    await expect(page.locator('#project-title')).toHaveText('orbital-industries');
    await app.evaluate(({ dialog, clipboard, Notification, BrowserWindow }, source) => {
      dialog.showOpenDialog = async () => ({ canceled: false, filePaths: [source] });
      let value = ''; clipboard.readText = () => value; clipboard.writeText = text => { value = text; };
      globalThis.tricorderNotifications = 0;
      Notification.isSupported = () => true;
      Notification.prototype.show = () => { globalThis.tricorderNotifications += 1; };
      BrowserWindow.getAllWindows()[0].isFocused = () => false;
    }, native);
    await projectTab(page, 'effort');
    await expect(page.locator('#content')).toContainText('À compléter');
    await expect(page.locator('#content')).not.toContainText('Mesures natives attribuées');
    await expect(page.locator('#content')).not.toContainText('odoo_usage.py');
    await projectTab(page, 'work');
    await expect(page.locator('#content')).toContainText('Temps réalisé');
    await expect(page.locator('[data-cockpit="associate"]')).toHaveCount(0);
    await page.evaluate(({ project, releaseId }) => window.tricorder.cockpit.bind({ project, release: releaseId, task: 'T02', flow: '.odoo-agents/flows/maintenance.json', provider: 'codex' }), { project, releaseId });
    await page.locator('[data-action="refresh"]').click();
    await expect(page.locator('.work-page')).toContainText('Votre décision est attendue');
    await expect(page.locator('.project-item.needs-human .human-alert')).toHaveText('!');
    expect(await app.evaluate(() => globalThis.tricorderNotifications)).toBeGreaterThan(0);
    await kanbanMode(page);
    await page.locator('[data-plan-filter="waiting"]').click();
    await expect(page.locator('.release-kanban .kanban-card')).toHaveCount(1);
    await expect(page.locator('.release-kanban .kanban-card')).toContainText('T02');
    await page.locator('[data-release-task="T02"]').click();
    await expect(page.locator('.board-detail')).toContainText('Planifier les interventions');
    await expect(page.locator('.board-detail')).not.toContainText('DO-NOT-EXPOSE-PRIVATE');
    await page.locator('[data-board-close]').click();
    await projectTab(page, 'plan');
    await expect(page.locator('.quality-panel')).toHaveCount(0);
    await projectTab(page, 'work');
    await expect(page.locator('#content')).not.toContainText('DO-NOT-EXPOSE-PRIVATE');
    const observed = await page.evaluate(p => window.tricorder.cockpit.observations(p), project);
    expect(observed[0].usage.active_seconds).toBe(20);
    expect(observed[0].usage.tokens.total_tokens).toBe(140);
    await projectTab(page, 'effort');
    await expect(page.locator('[data-time-task="T02"]')).toContainText('20 s');
    await expect(page.locator('[data-time-task="T02"]')).toContainText('140');
    expect(fs.existsSync(path.join(project, 'changelog', releaseId, 'effort.json'))).toBe(false);
    await page.screenshot({ path: 'test-results/roadmap-effort.png' });
    await projectTab(page, 'plan');
    await expect(page.locator('.task-acceptance')).toHaveCount(0);
    await expect(page.locator('[data-plan-mode="graph"]')).toBeVisible();
    await expect(page.locator('[data-cockpit="graph"]')).toHaveCount(0);
    await expect(page.locator('[data-cockpit="handoff"]')).toHaveCount(0);
    await projectView(page, 'environments');
    await expect(page.locator('#content')).not.toContainText('Fichiers reçus');
    await expect(page.locator('#content')).toContainText('Stack locale');
    await projectView(page, 'documents');
    await expect(page.locator('[data-cockpit="handoff"]')).toHaveCount(0);
    await page.locator('[data-files="inbox"]').first().click();
    await page.locator('[data-preview="inbox/ticket.eml"]').click();
    await expect(page.locator('.document-text')).toContainText('Demande synthétique');
    await page.locator('[data-action="modal-close"]').click();
    await page.locator('#content [data-cockpit="search"]').click();
    await page.locator('#global-query').fill('facturation');
    await page.locator('[data-cockpit="run-search"]').click();
    await expect(page.locator('.search-result').first()).toBeVisible();
    await page.locator('[data-action="modal-close"]').click();
    if (!(await page.locator('.sidebar-tools').evaluate(el => el.open))) await page.locator('.sidebar-tools > summary').click();
    await page.locator('[data-cockpit="palette"]').click();
    await page.locator('#skill-provider').selectOption('codex');
    await page.locator('#skill-filter').fill('odoo-env');
    await page.locator('[data-skill="odoo-env"]').click();
    await expect(page.locator('#modal')).toContainText('$odoo-env');
    await page.locator('[data-action="modal-close"]').click();
    await projectView(page, 'sources');
    await page.locator('[data-cockpit="profile"]').click();
    await page.locator('#profile-kind').selectOption('online');
    await page.locator('[data-cockpit="save-profile"]').click();
    await expect(page.locator('#content')).toContainText('Odoo Online');
    await page.locator('[data-cockpit="preferences"]').click();
    await page.locator('#pref-size').fill('16');
    await page.locator('#pref-contrast').check();
    await page.locator('#preferences-form button[type=submit]').click();
    await expect(page.locator('html')).toHaveClass('high-contrast');
    const persisted = JSON.parse(fs.readFileSync(path.join(temp, 'state/settings.json')));
    expect(persisted.ui.fontSize).toBe(16);
    expect(persisted.profiles[project].kind).toBe('online');
    expect(persisted.bindings[0].nativeId).toBe('synthetic-thread');
    const work = path.join(temp, 'worktree'); fs.mkdirSync(work);
    await app.evaluate(({ dialog }, target) => { dialog.showOpenDialog = async () => ({ canceled: false, filePaths: [target] }); }, work);
    await page.locator('[data-cockpit="profile"]').click();
    await page.locator('[data-cockpit="working-directory"]').click();
    await expect(page.locator('#modal')).not.toBeVisible();
    await projectTab(page, 'plan');
    await page.keyboard.press('Control+Shift+T');
    await expect(page.locator('.terminal-host')).toHaveCount(1);
    const terminal = await page.evaluate(async () => (await window.tricorder.terminals.list())[0]);
    expect(terminal.workingDirectory).toBe(work);
    expect(terminal.task).toBeNull();
    await expect(page.locator('#terminal-context')).toBeHidden();
    const activeTerminalTab = page.locator('.terminal-tab.active [data-session]');
    await activeTerminalTab.focus();
    await expect(page.locator('#terminal-context')).toBeVisible();
    await expect(page.locator('.terminal-session-title')).toHaveText(await activeTerminalTab.getAttribute('aria-label'));
    await page.locator('.xterm-helper-textarea:visible').focus();
    await expect(page.locator('#terminal-context')).toBeHidden();
    const terminalAfterFocus = (await page.evaluate(() => window.tricorder.terminals.list()))[0];
    expect([terminalAfterFocus.id, terminalAfterFocus.pid]).toEqual([terminal.id, terminal.pid]);
    await expect(page.locator('.provider-icon[aria-label="Shell"]').first()).toBeVisible();
    expect((await page.evaluate(async () => (await window.tricorder.terminals.list())[0])).task).toBeNull();
    fs.appendFileSync(native, JSON.stringify({ type: 'event_msg', timestamp: new Date().toISOString(), payload: { type: 'task_started', turn_id: 'turn2' } }) + '\n');
    await expect(page.locator('.human-alert')).toHaveCount(0, { timeout: 15000 });
    await projectTab(page, 'work');
    await page.screenshot({ path: 'test-results/roadmap-agents.png' });
    expect(errors).toEqual([]);
  } finally {
    if (app) await closeWindow(app).catch(() => app.process().kill('SIGKILL'));
    await cleanupBroker(path.join(temp, 'run/pty.sock'));
    fs.rmSync(temp, { recursive: true, force: true });
  }
});

test('intentions, dependency graph and concurrent activities remain usable at compact size and zoom', async () => {
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'tri-intentions-'));
  const home = path.join(temp, 'home'); fs.mkdirSync(home);
  const { project, releaseId } = fixture(home);
  write(path.join(project, 'changelog', releaseId, 'intentions.json'), { schema: 1, revision: 1, items: [
    { id: 'I01', text: 'Conserver la demande originale et ses décisions.', purpose: 'Rendre les factures fiables', status: 'planned',
      source: { path: `changelog/${releaseId}/demande.md`, original: 'Source figée initiale' }, tasks: ['T01', 'T03'], constraints: ['Copie locale'], questions: [], decisions: [{ at: '2026-09-15', text: 'Contrôler la somme des parties.' }] },
  ] });
  const now = new Date().toISOString();
  write(path.join(project, '.odoo-agents/orchestration.json'), { schema: 1, id: 'main-stable', project, release: releaseId,
    status: 'active', phase: 'Examine le résultat de T01', owner: 'Codex principal', provider: 'codex', model: 'principal',
    started_at: now, phase_started_at: now, updated_at: now, authorized_tasks: ['T01', 'T02', 'T03'] });
  const app = await electron.launch({ args: process.env.TRICORDER_EXECUTABLE ? [] : [root],
    ...(process.env.TRICORDER_EXECUTABLE ? { executablePath: process.env.TRICORDER_EXECUTABLE } : {}),
    env: { ...process.env, HOME: home, TRICORDER_HOME: home,
      TRICORDER_AGENTS_DIR: process.env.TRICORDER_AGENTS_DIR || path.join(os.homedir(), '.odoo19-agents'),
      TRICORDER_STATE_DIR: path.join(temp, 'state'), TRICORDER_RUNTIME_DIR: path.join(temp, 'run') } });
  const errors = [];
  try {
    const page = await app.firstWindow(); page.on('pageerror', e => errors.push(e.message));
    await page.setViewportSize({ width: 1440, height: 900 });
    await expect(page.locator('#release-select')).toHaveValue(releaseId);
    await app.evaluate(({ ipcMain }, { project, releaseId, now }) => {
      ipcMain.removeHandler('observations');
      ipcMain.handle('observations', () => ['T02', 'T03'].map((task, i) => ({ id: task, project, release: releaseId, task, provider: 'claude', role: i ? 'odoo-tester' : 'odoo-developer',
        agents: [{ nativeId: task, state: i ? 'tool' : 'active', stale: false, startedAt: now, stageStartedAt: now, lastAt: now, events: [] }] })));
    }, { project, releaseId, now });
    await expect(page.locator('#activity-strip')).toBeHidden();
    const nav = await page.locator('#tabs [data-view]').evaluateAll(nodes => nodes.map(n => n.dataset.view));
    expect(nav.indexOf('intentions')).toBeLessThan(nav.indexOf('plan'));
    await projectTab(page, 'intentions');
    await page.locator('[data-intention="I01"]').click();
    await expect(page.locator('.intention-detail')).toContainText('Conserver la demande originale');
    await expect(page.locator('.intention-detail')).toContainText('Contrôler la somme des parties');
    await page.locator('.intention-source summary').click();
    await expect(page.locator('.intention-source pre')).toContainText('Source figée initiale');
    await page.screenshot({ path: 'test-results/intentions-1440.png' });
    await page.locator('.intention-detail [data-task="T01"]').click();
    await expect(page.locator('#task-modal')).toContainText('Critères d’acceptation');
    await expect(page.locator('#task-modal [data-intention]')).toHaveCount(0);
    await page.keyboard.press('Escape');
    await projectTab(page, 'plan');
    await page.locator('[data-plan-mode="list"]').click();
    await expect(page.locator('[data-task="main-stable"]')).toHaveCount(0);
    await page.locator('[data-plan-filter="executing"]').click();
    await expect(page.locator('.task-card')).toHaveCount(2);
    await page.locator('[data-plan-filter="all"]').click();
    await page.locator('[data-plan-mode="graph"]').click();
    await page.locator('[data-graph-select="T03"]').focus();
    await page.keyboard.press('Enter');
    await expect(page.locator('.graph-selection')).toContainText('En amont : T01, T02');
    await expect(page.locator('[data-graph-select="T03"]')).toBeFocused();
    expect(await page.locator('.dependency-canvas > svg').evaluate(el => el.getBoundingClientRect().width)).toBeGreaterThan(500);
    await expect(page.locator('.dependency-edge')).toHaveCount(2);
    const stable = await page.locator('.dependency-canvas').evaluate(el => { window.graphNodeBeforeRefresh = el; return true; });
    expect(stable).toBe(true);
    await page.locator('[data-action="refresh"]').evaluate(el => el.click());
    await expect(page.locator('#sync-status')).toContainText('À jour');
    expect(await page.locator('.dependency-canvas').evaluate(el => el === window.graphNodeBeforeRefresh)).toBe(true);
    await page.screenshot({ path: 'test-results/dependencies-1440.png' });
    await app.evaluate(({ BrowserWindow }) => { const win = BrowserWindow.getAllWindows()[0]; win.setSize(1000, 700); win.webContents.setZoomFactor(1.25); });
    await page.setViewportSize({ width: 1000, height: 700 });
    await expect(page.locator('#tabs [data-view="intentions"]')).toBeInViewport();
    await page.locator('[data-plan-mode="list"]').click();
    await expect(page.locator('[data-plan-mode="list"]')).toBeFocused();
    await projectTab(page, 'work');
    await expect(page.locator('#content')).toContainText('Temps réalisé');
    const metrics = await page.evaluate(() => {
      const rgb = value => value.match(/[\d.]+/g).slice(0, 3).map(Number);
      const luminance = value => rgb(value).map(v => { v /= 255; return v <= .04045 ? v / 12.92 : ((v + .055) / 1.055) ** 2.4; }).reduce((sum, v, i) => sum + v * [.2126, .7152, .0722][i], 0);
      const ratios = [...document.querySelectorAll('.activity-row strong, .activity-row > span, #content h2')].map(el => {
        let parent = el, background;
        while (parent) { background = getComputedStyle(parent).backgroundColor; if (background !== 'rgba(0, 0, 0, 0)' && background !== 'transparent') break; parent = parent.parentElement; }
        const fg = luminance(getComputedStyle(el).color), bg = luminance(background || 'rgb(0, 0, 0)');
        return (Math.max(fg, bg) + .05) / (Math.min(fg, bg) + .05);
      });
      return { width: innerWidth, height: innerHeight, scrollWidth: document.documentElement.scrollWidth, ratios };
    });
    expect(metrics.scrollWidth).toBeLessThanOrEqual(metrics.width);
    expect(Math.min(...metrics.ratios)).toBeGreaterThanOrEqual(4.5);
    fs.writeFileSync('test-results/ui-measurements.json', JSON.stringify(metrics, null, 2));
    await page.screenshot({ path: 'test-results/activities-1000-zoom125.png' });
    await app.evaluate(({ BrowserWindow }) => { const win = BrowserWindow.getAllWindows()[0]; win.setSize(1000, 900); win.webContents.setZoomFactor(1); });
    await page.setViewportSize({ width: 1000, height: 900 });
    await kanbanMode(page);
    await page.screenshot({ path: 'test-results/orchestration-1000.png' });
    if (!(await page.locator('.sidebar-tools').evaluate(el => el.open))) await page.locator('.sidebar-tools > summary').click();
    await page.locator('[data-view="kanban"]').click();
    await page.locator('[data-action="kanban-executing"]').click();
    await expect(page.locator('.kanban-card')).toHaveCount(2);
    expect(errors).toEqual([]);
  } finally {
    await closeWindow(app).catch(() => app.process().kill('SIGKILL'));
    await cleanupBroker(path.join(temp, 'run/pty.sock')); fs.rmSync(temp, { recursive: true, force: true });
  }
});

test('live requests appear before planning and reconcile with tasks without manual refresh', async () => {
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'tri-live-requests-'));
  const home = path.join(temp, 'home'); fs.mkdirSync(home);
  const { project, releaseId } = fixture(home);
  const app = await electron.launch({ args: process.env.TRICORDER_EXECUTABLE ? [] : [root],
    ...(process.env.TRICORDER_EXECUTABLE ? { executablePath: process.env.TRICORDER_EXECUTABLE } : {}),
    env: { ...process.env, HOME: home, TRICORDER_HOME: home,
      TRICORDER_AGENTS_DIR: process.env.TRICORDER_AGENTS_DIR || path.join(os.homedir(), '.odoo19-agents'),
      TRICORDER_STATE_DIR: path.join(temp, 'state'), TRICORDER_RUNTIME_DIR: path.join(temp, 'run') } });
  try {
    const page = await app.firstWindow();
    await expect(page.locator('#release-select')).toHaveValue(releaseId);
    const newRelease = '2026-09-15_01_demandes-en-direct';
    const folder = path.join(project, 'changelog', newRelease);
    write(path.join(folder, 'README.md'), '<!-- release ouverte -->\n# Demandes en direct');
    const register = { schema: 1, revision: 1, items: [{ id: 'I01', text: 'Conserver exactement ma demande initiale', purpose: 'Demande reçue en direct', status: 'clarify', tasks: [] }] };
    write(path.join(folder, 'intentions.json'), register);
    await expect(page.locator(`#release-select option[value="${newRelease}"]`)).toHaveCount(1, { timeout: 10000 });
    await page.locator('#release-select').selectOption(newRelease);
    await projectTab(page, 'plan');
    await page.locator('[data-plan-mode="list"]').click();
    await expect(page.locator('[data-plan-task="intention:I01"]')).toContainText('À préciser');
    await expect(page.locator('[data-plan-task="intention:I01"] [data-task]')).toHaveCount(0);
    await kanbanMode(page);
    await expect(page.locator('.release-kanban [data-intention="I01"]')).toBeVisible();
    if (!(await page.locator('.sidebar-tools').evaluate(el => el.open))) await page.locator('.sidebar-tools > summary').click();
    await page.locator('[data-view="kanban"]').click();
    await page.locator('[data-kanban-intention="I01"]').click();
    await expect(page.locator('.intention-detail')).toContainText('Conserver exactement ma demande initiale');
    await projectTab(page, 'plan');
    await page.locator('[data-plan-mode="list"]').click();
    const source = `changelog/${newRelease}/demande.md`; write(path.join(project, source), '# Demande conservée');
    write(path.join(folder, 'plan.json'), { schema: 1, tasks: [{ id: 'T01', title: 'Résultat retenu après revue', request: source,
      acceptance: ['Résultat vérifié'], risk: 'normal', route: 'module', scopes: ['orbital_custom'], depends_on: [], intentions: ['I01'] }] });
    register.items[0].status = 'planned'; register.items[0].tasks = ['T01']; register.revision++;
    write(path.join(folder, 'intentions.json'), register);
    await expect(page.locator('[data-plan-task="T01"]')).toContainText('Résultat retenu', { timeout: 10000 });
    await expect(page.locator('[data-plan-task="intention:I01"]')).toHaveCount(0);
    await kanbanMode(page);
    await expect(page.locator('.release-kanban [data-release-task="T01"]')).toBeVisible();
    await expect(page.locator('.release-kanban [data-intention="I01"]')).toHaveCount(0);
    // Removing the planned task must expose the unmet request again, not lose it.
    write(path.join(folder, 'plan.json'), { schema: 1, tasks: [] });
    await expect(page.locator('.release-kanban [data-intention="I01"]')).toBeVisible({ timeout: 10000 });
    await page.screenshot({ path: 'test-results/live-requests.png' });
    await projectTab(page, 'intentions');
    await page.locator('.intention-card[data-intention="I01"]').click();
    await expect(page.locator('.intention-detail')).toContainText('Conserver exactement ma demande initiale');
  } finally {
    await closeWindow(app).catch(() => app.process().kill('SIGKILL'));
    await cleanupBroker(path.join(temp, 'run/pty.sock')); fs.rmSync(temp, { recursive: true, force: true });
  }
});

test('UI review: bundled typography, expanded views and dialogs stay readable at desktop and compact zoom', async () => {
  test.setTimeout(120000);
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'tri-ui-review-'));
  const home = path.join(temp, 'home'); fs.mkdirSync(home);
  const { project, releaseId } = fixture(home);
  write(path.join(project, 'changelog', releaseId, 'README.md'), '<!-- release ouverte -->\n# Guide de lecture\n\n## Résultat attendu\n\nUn document conserve une typographie de lecture.\n\n| Repère | Explication |\n| --- | --- |\n| T01 | Une phrase longue qui doit rester lisible dans le tableau sans forcer le défilement de toute la fenêtre. |\n\n```\n' + 'trace-'.repeat(80) + '\n```');
  write(path.join(project, 'changelog', releaseId, 'intentions.json'), { schema: 1, revision: 1, items: [
    { id: 'I01', purpose: 'Rendre les factures fiables', text: 'Conserver la demande originale et ses décisions.', status: 'planned',
      tasks: ['T01'], constraints: ['Copie locale'], source: { path: `changelog/${releaseId}/demande.md`, original: 'Demande originale conservée.' } },
  ] });
  write(path.join(project, '.odoo-agents/flows/express-caption.json'), { kind: 'express', status: 'complete',
    graph_snapshot: { nodes: { express_qa: { description: 'Contrôles ciblés' }, task_done: { description: 'Terminée' } } },
    events: [{ node: 'express_qa', outcome: 'pass', evidence: ['preuve/'.repeat(60)] }, { node: 'task_done', outcome: 'done' }],
    updated_at: '2026-09-11T09:00:00Z' });
  const app = await electron.launch({ args: process.env.TRICORDER_EXECUTABLE ? [] : [root],
    ...(process.env.TRICORDER_EXECUTABLE ? { executablePath: process.env.TRICORDER_EXECUTABLE } : {}),
    env: { ...process.env, HOME: home, TRICORDER_HOME: home,
      TRICORDER_AGENTS_DIR: process.env.TRICORDER_AGENTS_DIR || path.join(os.homedir(), '.odoo19-agents'),
      TRICORDER_STATE_DIR: path.join(temp, 'state'), TRICORDER_RUNTIME_DIR: path.join(temp, 'run') } });
  try {
    const page = await app.firstWindow();
    await expect(page.locator('#release-select')).toHaveValue(releaseId);
    const fonts = await page.evaluate(async () => {
      const results = [];
      for (const family of ['IBM Plex Sans', 'IBM Plex Mono']) {
        const faces = await document.fonts.load(`400 16px "${family}"`, 'Été français Œuvre');
        results.push({ family, loaded: faces.length > 0 && faces.every(face => face.status === 'loaded') });
      }
      return results;
    });
    expect(fonts.every(font => font.loaded), JSON.stringify(fonts)).toBe(true);
    const check = async (name, width) => {
      const metrics = await page.evaluate(() => {
        const dialog = [...document.querySelectorAll('dialog[open]')].at(-1);
        const root = dialog || document.querySelector('#content:not([hidden])') || document.querySelector('#terminal-workspace');
        return { overflow: root.scrollWidth > root.clientWidth + 1,
          documentOverflow: document.documentElement.scrollWidth > innerWidth,
          dialogName: dialog ? document.getElementById(dialog.getAttribute('aria-labelledby'))?.textContent : true };
      });
      expect(metrics.overflow, name + ' horizontal overflow').toBe(false);
      expect(metrics.documentOverflow, name + ' window overflow').toBe(false);
      expect(metrics.dialogName, name + ' accessible dialog title').toBeTruthy();
      if (await page.locator('#modal[open] .modal-close').isVisible()) {
        await expect(page.locator('#modal .modal-close')).toBeInViewport();
        const close = await page.locator('#modal .modal-close').boundingBox(), dialog = await page.locator('#modal').boundingBox();
        expect(close.x, 'Close stays on the right while scrolling').toBeGreaterThan(dialog.x + dialog.width / 2);
      }
      await page.screenshot({ path: `test-results/review-${name}-${width}.png` });
    };
    for (const [width, height, zoom] of [[1440, 900, 1], [1000, 700, 1.25]]) {
      await app.evaluate(({ BrowserWindow }, zoom) => BrowserWindow.getAllWindows()[0].webContents.setZoomFactor(zoom), zoom);
      await page.setViewportSize({ width, height });
      await projectTab(page, 'terminal');
      if (width === 1440) {
        await check('terminal-empty', width);
        await page.locator('#terminal-empty [data-action="new-terminal"]').click();
        await expect(page.locator('.xterm-screen')).toBeVisible();
      }
      await page.locator('[data-action="find"]').click();
      await expect(page.locator('#terminal-search input')).toBeFocused();
      await check('terminal-search', width);
      await page.keyboard.press('Escape');
      await expect(page.locator('#terminal-search')).toBeHidden();
      await expect(page.locator('.xterm-helper-textarea')).toBeFocused();
      await projectTab(page, 'intentions');
      await page.locator('[data-intention="I01"]').click();
      await page.locator('.intention-source summary').click();
      await check('intention-detail', width);
      await projectTab(page, 'plan');
      await page.locator('[data-plan-mode="list"]').click();
      await page.locator('[data-task="T02"]').click();
      await check('task-detail', width);
      await page.keyboard.press('Escape');
      await expect(page.locator('[data-task="T02"]')).toBeFocused();
      await page.locator('.release-links [data-document]').click();
      await expect(page.locator('.markdown-preview h2')).toHaveText('Résultat attendu');
      const documentStyles = await page.locator('.markdown-preview').evaluate(el => ({
        font: getComputedStyle(el.querySelector('h2')).fontFamily,
        uppercase: getComputedStyle(el.querySelector('h2')).textTransform,
        whitespace: getComputedStyle(el.querySelector('td:last-child')).whiteSpace,
      }));
      expect(documentStyles.font).toContain('IBM Plex Sans');
      expect(documentStyles.uppercase).toBe('none'); expect(documentStyles.whitespace).toBe('normal');
      await check('markdown', width);
      await page.locator('.markdown-source summary').click();
      await check('markdown-source', width);
      await page.keyboard.press('Escape');
      await projectTab(page, 'express');
      await check('express', width);
      await projectTab(page, 'work');
      await check('status', width);
      await projectTab(page, 'effort');
      const breakdown = page.locator('[data-time-task="T02"] details');
      if (!(await breakdown.evaluate(el => el.open))) await breakdown.locator('summary').click();
      await expect(breakdown.locator('.pilotage-times')).toBeVisible();
      await breakdown.scrollIntoViewIfNeeded();
      await check('agent-time', width);
      await projectView(page, 'environments');
      await page.locator('[data-cockpit="profile"]').first().click();
      await check('project-profile', width);
      await page.keyboard.press('Escape');
      await projectView(page, 'documents');
      await page.locator('.chips [data-files="changelog"]').click();
      await expect(page.locator('.chips [data-files="changelog"]')).toHaveAttribute('aria-pressed', 'true');
      await check('file-folder', width);
      await page.locator('[data-cockpit="search"]').click();
      await page.locator('#global-query').fill('facturation');
      await page.keyboard.press('Enter');
      await expect(page.locator('#global-results')).toContainText('orbital-industries');
      await check('search-results', width);
      await page.keyboard.press('Escape');
      if (!(await page.locator('.sidebar-tools').evaluate(el => el.open))) await page.locator('.sidebar-tools > summary').click();
      for (const [action, name] of [['palette', 'skills'], ['quotas', 'quotas'], ['preferences', 'preferences']]) {
        await page.locator(`[data-cockpit="${action}"]`).first().click();
        await expect(page.locator('#modal')).toBeVisible();
        if (action === 'preferences') await page.locator('.keyboard-help summary').click();
        await check(name, width);
        if (action === 'palette') {
          await page.locator('#skill-filter').fill('odoo-plan');
          await page.locator('[data-skill="odoo-plan"]').click();
          await check('prepared-command', width);
        }
        await page.keyboard.press('Escape');
      }
      if (!(await page.locator('.sidebar-tools').evaluate(el => el.open))) await page.locator('.sidebar-tools > summary').click();
    await page.locator('[data-action="about"]').click();
      await check('about', width);
      await page.keyboard.press('Escape');
    }
  } finally {
    await closeWindow(app).catch(() => app.process().kill('SIGKILL'));
    await cleanupBroker(path.join(temp, 'run/pty.sock')); fs.rmSync(temp, { recursive: true, force: true });
  }
});


test('work page starts a contextual request and resumes a task without changing its state', async () => {
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'tri-work-'));
  const home = path.join(temp, 'home'); fs.mkdirSync(home);
  const { project, releaseId } = fixture(home);
  const bin = path.join(temp, 'bin'); fs.mkdirSync(bin);
  const fake = path.join(bin, 'codex');
  write(fake, '#!/usr/bin/env python3\nimport sys\nprint("PROMPT:" + sys.argv[-1])\n'); fs.chmodSync(fake, 0o755);
  write(path.join(project, '.odoo-agents/JOURNAL.md'), '## 2026-09-30 — Retour synthétique\n- Appris : Conserver les exceptions.\n');
  require('node:child_process').execFileSync('python3', [path.join(process.env.TRICORDER_AGENTS_DIR || path.join(os.homedir(), '.odoo19-agents'), 'scripts/odoo_feedback.py'), 'collect', project, '--release', releaseId]);
  const app = await electron.launch({ args: process.env.TRICORDER_EXECUTABLE ? [] : [root],
    ...(process.env.TRICORDER_EXECUTABLE ? { executablePath: process.env.TRICORDER_EXECUTABLE } : {}),
    env: { ...process.env, PATH: bin + ':' + process.env.PATH, SHELL: '/bin/bash', HOME: home, TRICORDER_HOME: home,
      TRICORDER_STATE_DIR: path.join(temp, 'state'), TRICORDER_RUNTIME_DIR: path.join(temp, 'run'),
      TRICORDER_AGENTS_DIR: process.env.TRICORDER_AGENTS_DIR || path.join(os.homedir(), '.odoo19-agents') } });
  try {
    const page = await app.firstWindow();
    await expect(page.locator('.work-page')).toBeVisible();
    await expect(page.locator('#tabs [data-view="plan"]')).toBeVisible();
    await expect(page.locator('.work-page')).not.toContainText('retours à qualifier');
    await projectTab(page, 'knowledge');
    await expect(page.locator('.knowledge-page')).toContainText('Aucun apprentissage établi');
    await page.keyboard.press('Alt+1');
    await expect(page.locator('.work-page')).toBeVisible();
    await page.screenshot({ path: 'test-results/travail.png' });
    await page.locator('[data-action="work-request"]').click();
    const request = 'Conserver les avoirs,\tsauf société B.';
    await page.locator('#work-form textarea').fill(request);
    await page.locator('#work-form [type="submit"]').click();
    await expect(page.locator('.xterm-screen')).toContainText('sauf société B.', { timeout: 10000 });
    await expect(page.locator('.xterm-screen')).toContainText('PROMPT:/odoo-new');
    const before = fs.readFileSync(path.join(project, 'changelog', releaseId, 'plan.json'), 'utf8');
    await projectTab(page, 'work');
    await page.locator('[data-work-resume="T02"]').click();
    await page.locator('#work-form [type="submit"]').click();
    await expect(page.locator('.xterm-screen:visible')).toContainText('PROMPT:/odoo-start');
    const sessions = await page.evaluate(() => window.tricorder.terminals.list());
    expect(sessions).toHaveLength(2);
    await projectTab(page, 'work');
    await page.locator('[data-work-resume="T02"]').click();
    await expect(page.locator('#modal')).not.toBeVisible();
    expect(await page.evaluate(() => window.tricorder.terminals.list())).toHaveLength(2);
    expect(sessions.find(s => s.task === 'T02').release).toBe(releaseId);
    expect(fs.readFileSync(path.join(project, 'changelog', releaseId, 'plan.json'), 'utf8')).toBe(before);
  } finally {
    await closeWindow(app).catch(() => app.process().kill('SIGKILL'));
    await cleanupBroker(path.join(temp, 'run/pty.sock'));
    fs.rmSync(temp, { recursive: true, force: true });
  }
});

test('appearance: light, dark and system persist with live terminals and a readable release hierarchy', async () => {
  test.setTimeout(90000);
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'tri-appearance-'));
  const home = path.join(temp, 'home'); fs.mkdirSync(home);
  const { project, releaseId } = fixture(home);
  require('node:child_process').execFileSync('git', ['init', '-b', 'feat/facturation-clients'], { cwd: project, stdio: 'ignore' });
  const options = { args: process.env.TRICORDER_EXECUTABLE ? [] : [root],
    ...(process.env.TRICORDER_EXECUTABLE ? { executablePath: process.env.TRICORDER_EXECUTABLE } : {}),
    env: { ...process.env, HOME: home, TRICORDER_HOME: home,
      TRICORDER_AGENTS_DIR: process.env.TRICORDER_AGENTS_DIR || path.join(os.homedir(), '.odoo19-agents'),
      TRICORDER_STATE_DIR: path.join(temp, 'state'), TRICORDER_RUNTIME_DIR: path.join(temp, 'run') } };
  let app = await electron.launch(options);
  const errors = [];
  try {
    let page = await app.firstWindow(); page.on('pageerror', e => errors.push(e.message));
    await page.setViewportSize({ width: 1440, height: 900 });
    await expect(page.locator('#release-select')).toHaveValue(releaseId);
    await projectTab(page, 'work');
    await expect(page.locator('#release-title')).toHaveText('Facturation & maintenance récurrente');
    expect(await page.locator('#release-title').evaluate(el => parseFloat(getComputedStyle(el).fontSize))).toBeGreaterThanOrEqual(22);
    await expect(page.locator('#environment-select')).toBeVisible(); // Terminal remains visible beside the release.
    await expect(page.locator('.project-header')).not.toContainText('feat/facturation-clients');
    await projectTab(page, 'terminal');
    await expect(page.locator('.git-context')).toContainText('feat/facturation-clients');
    await page.locator('#terminal-empty [data-action="new-terminal"]').click();
    await expect(page.locator('.xterm-screen')).toBeVisible();
    const terminal = (await page.evaluate(() => window.tricorder.terminals.list()))[0];
    await page.evaluate(id => window.tricorder.terminals.write({session: id, data: "printf 'THEME-PRESERVED\\n'\n"}), terminal.id);
    await expect(page.locator('.xterm-screen')).toContainText('THEME-PRESERVED');
    for (const theme of ['light', 'dark']) {
      await page.locator(`[data-theme-choice="${theme}"]`).click();
      await expect(page.locator('html')).toHaveAttribute('data-theme', theme);
      await expect(page.locator(`[data-theme-choice="${theme}"]`)).toHaveAttribute('aria-pressed', 'true');
      await expect(page.locator('.xterm-screen')).toContainText('THEME-PRESERVED');
      expect((await page.evaluate(() => window.tricorder.terminals.list()))[0].id).toBe(terminal.id);
      for (const view of ['work', 'plan', 'intentions', 'knowledge', 'effort', 'terminal']) {
        await projectTab(page, view);
        await page.screenshot({animations: 'disabled', path: `test-results/appearance-${theme}-${view}.png`});
      }
      await projectTab(page, 'work');
      const contrast = await page.evaluate(() => {
        const css = getComputedStyle(document.documentElement);
        const luminance = hex => {
          const c = hex.trim().slice(1).match(/../g).map(v => parseInt(v, 16) / 255).map(v => v <= .04045 ? v / 12.92 : ((v + .055) / 1.055) ** 2.4);
          return c[0] * .2126 + c[1] * .7152 + c[2] * .0722;
        };
        const ratio = (a, b) => { const x = luminance(css.getPropertyValue(a)), y = luminance(css.getPropertyValue(b)); return (Math.max(x,y)+.05)/(Math.min(x,y)+.05); };
        return ['--bg', '--surface-1', '--sidebar-bg'].flatMap(bg => ['--text', '--text-2', '--text-3'].map(fg => ({fg,bg,ratio:ratio(fg,bg)})));
      });
      for (const sample of contrast) expect(sample.ratio, `${theme} ${sample.fg} on ${sample.bg}`).toBeGreaterThanOrEqual(4.5);
      await page.locator('[data-cockpit="preferences"]').click();
      await expect(page.locator('#pref-theme')).toHaveValue(theme);
      await page.locator('#pref-contrast').check();
      await page.locator('#preferences-form button[type=submit]').click();
      await expect(page.locator('html')).toHaveClass(/high-contrast/);
      await page.locator('[data-cockpit="preferences"]').click();
      await page.locator('#pref-contrast').uncheck();
      await page.locator('#preferences-form button[type=submit]').click();
    }
    // A manual choice wins over OS changes; System follows changes while open.
    await page.emulateMedia({colorScheme:'light'});
    await expect(page.locator('html')).toHaveAttribute('data-theme','dark');
    await page.locator('[data-theme-choice="system"]').click();
    await expect(page.locator('html')).toHaveAttribute('data-theme','light');
    await page.emulateMedia({colorScheme:'dark'});
    await expect(page.locator('html')).toHaveAttribute('data-theme','dark');
    await page.locator('[data-theme-choice="light"]').click();
    const saved = await page.evaluate(() => window.tricorder.settings({ui:{theme:'invalid-theme'}}));
    expect(saved.ui.theme).toBe('light');
    // Long release titles wrap; the whole window must remain usable at 125%.
    const longTitle = 'Facturation récurrente et suivi des interventions — consolidation des sociétés et validation des documents clients';
    write(path.join(project, 'changelog', releaseId, 'README.md'), `<!-- release ouverte -->\n# ${longTitle}\n`);
    await page.locator('[data-action="refresh"]').click();
    await expect(page.locator('#release-title')).toHaveText(longTitle);
    await app.evaluate(({BrowserWindow}) => BrowserWindow.getAllWindows()[0].webContents.setZoomFactor(1.25));
    await page.setViewportSize({width:1000,height:700});
    for (const theme of ['light', 'dark']) {
      await page.locator(`[data-theme-choice="${theme}"]`).click();
      await expect(page.locator('html')).toHaveAttribute('data-theme',theme);
      const size = await page.evaluate(() => ({width:innerWidth,scroll:document.documentElement.scrollWidth,title:document.querySelector('#release-title').getBoundingClientRect().right}));
      expect(size.scroll).toBeLessThanOrEqual(size.width);
      expect(size.title).toBeLessThanOrEqual(size.width);
      await expect(page.locator('#tabs [data-view="effort"]')).toBeInViewport();
      await page.screenshot({animations:'disabled',path:`test-results/appearance-${theme}-compact.png`});
    }
    await page.locator('[data-theme-choice="light"]').click();
    await expect(page.locator('html')).toHaveAttribute('data-theme','light');
    await closeWindow(app);
    app = await electron.launch(options); page = await app.firstWindow();
    await expect(page.locator('#release-select')).toHaveValue(releaseId);
    await expect(page.locator('html')).toHaveAttribute('data-theme','light');
    await expect(page.locator('[data-theme-choice="light"]')).toHaveAttribute('aria-pressed','true');
    await projectTab(page,'terminal');
    await expect(page.locator('.xterm-screen')).toContainText('THEME-PRESERVED');
    expect((await page.evaluate(() => window.tricorder.terminals.list()))[0].id).toBe(terminal.id);
    expect(errors).toEqual([]);
  } finally {
    await closeWindow(app).catch(() => app.process().kill('SIGKILL'));
    await cleanupBroker(path.join(temp,'run/pty.sock')); fs.rmSync(temp,{recursive:true,force:true});
  }
});

test('window integration preserves the native conversation while inspecting phases and the library', async () => {
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'tri-one-workflow-'));
  const home = path.join(temp, 'home'); fs.mkdirSync(home);
  const { project, releaseId } = fixture(home);
  const bin = path.join(temp, 'bin'); fs.mkdirSync(bin);
  for (const name of ['codex', 'claude']) {
    const file = path.join(bin, name);
    write(file, '#!/usr/bin/env python3\nimport sys\nprint("SELECTED:' + name + '", flush=True)\nprint("PROMPT:" + sys.argv[-1], flush=True)\nfor line in sys.stdin:\n    print("REPLY:" + line.strip(), flush=True)\n'); fs.chmodSync(file, 0o755);
  }
  const app = await electron.launch({ args: process.env.TRICORDER_EXECUTABLE ? [] : [root],
    ...(process.env.TRICORDER_EXECUTABLE ? { executablePath: process.env.TRICORDER_EXECUTABLE } : {}),
    env: { ...process.env, PATH: bin + ':' + process.env.PATH, SHELL: '/bin/bash', HOME: home, TRICORDER_HOME: home,
      TRICORDER_STATE_DIR: path.join(temp, 'state'), TRICORDER_RUNTIME_DIR: path.join(temp, 'run'), TRICORDER_TEST_MODE: '1',
      TRICORDER_AGENTS_DIR: process.env.TRICORDER_AGENTS_DIR || path.join(os.homedir(), '.odoo19-agents') } });
  try {
    const page = await app.firstWindow();
    await expect(page.getByRole('region', { name: 'Workflow de release' })).toBeVisible();
    await expect(page.locator('#terminal-workspace')).toBeVisible();
    await page.getByLabel('Fournisseur IA', { exact: true }).selectOption('claude');
    await page.getByLabel('Workflow', { exact: true }).selectOption('release');
    await page.getByRole('button', { name: 'Démarrer le workflow', exact: true }).click();
    await page.locator('#workflow-form [type=submit]').click();
    await expect(page.locator('.xterm-screen:visible')).toContainText('SELECTED:claude');
    await expect(page.locator('.xterm-screen:visible')).toContainText('PROMPT:/odoo-plan');
    const sessions = await page.evaluate(() => window.tricorder.terminals.list());
    expect(sessions).toHaveLength(1);
    expect(sessions[0].release).toBe(releaseId);
    for (const stage of ['collect', 'plan', 'start', 'close']) {
      await page.locator('[data-work-stage="' + stage + '"]').click();
      expect(await page.evaluate(() => window.tricorder.terminals.list())).toHaveLength(1);
      await page.getByRole('button', { name: 'Retrouver la conversation', exact: true }).click();
    }
    await page.locator('.xterm-helper-textarea:visible').focus();
    await page.keyboard.type('Voici mon intention'); await page.keyboard.press('Enter');
    await expect(page.locator('.xterm-screen:visible')).toContainText('REPLY:Voici mon intention');
    const contentsId = await page.evaluate(() => { window.conversationMarker = 'preserved'; return true; });
    expect(contentsId).toBe(true);
    if (!(await page.locator('.sidebar-tools').evaluate(el => el.open))) await page.locator('.sidebar-tools > summary').click();
    await page.locator('[data-action=workflow-workspace]').click();
    expect(app.context().pages()).toHaveLength(1);
    const studio = page;
    await expect(studio.getByRole('heading', { name: 'Un workflow clair.' })).toBeVisible();
    expect(await app.evaluate(({ BrowserWindow }) => BrowserWindow.getAllWindows().length)).toBe(1);
    await studio.getByRole('button', { name: 'Essayer un exemple' }).click();
    await studio.locator('.node[data-id="analyse"]').click();
    // Selection keeps the compact graph visible; editing is an explicit action.
    await expect(studio.locator('.canvas-area')).toBeVisible();
    await studio.getByRole('button', { name: 'Propriétés', exact: true }).click();
    await studio.getByLabel('Nom du bloc', { exact: true }).fill('Brouillon non appliqué');
    await page.locator('#project-list [data-project=' + JSON.stringify(project) + ']').click();
    expect(await page.evaluate(() => window.conversationMarker)).toBe('preserved');
    expect((await page.evaluate(() => window.tricorder.terminals.list()))[0].pid).toBe(sessions[0].pid);
    await page.locator('.xterm-helper-textarea:visible').focus();
    await page.keyboard.type('Je poursuis la conversation'); await page.keyboard.press('Enter');
    await expect(page.locator('.xterm-screen:visible')).toContainText('REPLY:Je poursuis la conversation');
    if (!(await page.locator('.sidebar-tools').evaluate(el => el.open))) await page.locator('.sidebar-tools > summary').click();
    await page.locator('[data-action=workflow-workspace]').click();
    await expect(studio.getByLabel('Nom du bloc', { exact: true })).toHaveValue('Brouillon non appliqué');
    expect(await app.evaluate(({ BrowserWindow }) => BrowserWindow.getAllWindows().length)).toBe(1);
    await page.locator('#project-list [data-project=' + JSON.stringify(project) + ']').click();
    await page.getByRole('button', { name: 'Agrandir le terminal', exact: true }).click();
    await expect(page.locator('#content')).toBeHidden();
    await page.getByRole('button', { name: 'Afficher le workflow', exact: true }).click();
    for (const width of [1440, 1024]) {
      await page.setViewportSize({ width, height: 900 });
      await expect(page.locator('#terminal-workspace')).toBeVisible();
      await expect(page.getByRole('region', { name: 'Workflow de release' })).toBeVisible();
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
      await page.screenshot({ path: test.info().outputPath(`workflow-conversation-${width}.png`) });
    }
    // Changing provider is an explicit new conversation; the first stays alive.
    await page.getByLabel('Fournisseur IA', { exact: true }).selectOption('codex');
    await page.getByRole('button', { name: 'Démarrer le workflow', exact: true }).click();
    await page.locator('#workflow-form textarea').fill('Mon nouveau contexte');
    await page.locator('#workflow-form [type=submit]').click();
    await expect(page.locator('.xterm-screen:visible')).toContainText('SELECTED:codex');
    const latest = await page.evaluate(() => window.tricorder.terminals.list());
    expect(latest).toHaveLength(2);
    expect(latest[0].pid).toBe(sessions[0].pid);
  } finally {
    await closeWindow(app);
    await cleanupBroker(path.join(temp, 'run/pty.sock'));
    fs.rmSync(temp, { recursive: true, force: true });
  }
});
