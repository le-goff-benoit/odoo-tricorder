const {test,expect,_electron:electron}=require('/home/blegoff/odoo-tricorder/node_modules/@playwright/test');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {cleanupBroker}=require('/home/blegoff/odoo-tricorder/tests/terminal-fixture.cjs');
const root='/home/blegoff/odoo-tricorder';let app,page,directory,run,project;
const call=(action,data={})=>page.evaluate(payload=>window.studio.request(payload),{action,...data});
const input=()=>page.getByLabel('Nouvelle intention',{exact:true});
const add=()=>page.getByRole('button',{name:'Ajouter à la liste',exact:true});
const stored=async()=>(await call('run.get',{run:run.id})).run.nodes.intentions.collection.items.map(i=>i.text);

// Delay acknowledgement, not execution: reproduce typing while an accepted
// write is in flight. This must not depend on machine speed or a real provider.
async function holdNextAdd(){await app.evaluate(({ipcMain})=>{
 const original=ipcMain._invokeHandlers.get('studio:request');let held=false;
 globalThis.collectionAck={waiting:false,release:null};
 ipcMain.removeHandler('studio:request');ipcMain.handle('studio:request',async(event,payload)=>{
  const result=await original(event,payload);
  if(payload.action==='collection.change'&&payload.operation==='add'&&!held){held=true;globalThis.collectionAck.waiting=true;await new Promise(resolve=>globalThis.collectionAck.release=resolve);}
  return result;
 });
});}
const waitAck=()=>expect.poll(()=>app.evaluate(()=>globalThis.collectionAck.waiting)).toBe(true);
const releaseAck=()=>app.evaluate(()=>globalThis.collectionAck.release());

test.beforeEach(async()=>{
 directory=fs.mkdtempSync(path.join(os.tmpdir(),'tricorder-collection-input-'));
 const bin=path.join(directory,'bin');fs.mkdirSync(bin);
 for(const cli of ['codex','claude'])fs.writeFileSync(path.join(bin,cli),'#!/bin/sh\nexit 78\n',{mode:0o755});
 app=await electron.launch({executablePath:process.env.TRICORDER_EXECUTABLE,args:process.env.TRICORDER_EXECUTABLE?[]:[root],env:{PATH:bin+':/usr/bin:/bin',HOME:directory,DISPLAY:process.env.DISPLAY,XAUTHORITY:process.env.XAUTHORITY,LANG:'C.UTF-8',XDG_CONFIG_HOME:path.join(directory,'config'),XDG_DATA_HOME:path.join(directory,'data'),XDG_CACHE_HOME:path.join(directory,'cache'),CODEX_HOME:path.join(directory,'codex'),CLAUDE_CONFIG_DIR:path.join(directory,'claude'),TRICORDER_HOME:directory,TRICORDER_STATE_DIR:directory,TRICORDER_RUNTIME_DIR:path.join(directory,'runtime'),TRICORDER_AGENTS_DIR:path.join(directory,'no-pack'),TRICORDER_TEST_MODE:'1',PYTHONDONTWRITEBYTECODE:'1'}});
 page=await app.firstWindow();await page.setViewportSize({width:1400,height:950});
 await expect(page.getByRole('heading',{name:'Un workflow clair.'})).toBeVisible();
 project=await call('project.create',{title:'Collecte de besoins synthétiques'});
 const graph=await call('workflow.save',{project:project.id,graph:{id:'collect',title:'Recueillir les besoins',schema:2,nodes:[{id:'intentions',kind:'input',title:'Recueillir les intentions',outputs:{intentions:{type:'array',items:'object',required:true,minItems:1,maxItems:100}},position:{x:60,y:60}}],edges:[]}});
 run=await call('run.start',{project:project.id,graph,simulation:true});
 await page.locator('[data-workflow-route=projects]').click();await page.locator('.project-card').filter({hasText:project.title}).click();await page.locator(`[data-action=open-run][data-id="${run.id}"]`).click();await page.getByRole('button',{name:'Détail',exact:true}).click();
});
test.afterEach(async()=>{if(app){await app.evaluate(()=>globalThis.collectionAck?.release?.()).catch(()=>{});await app.close();}for(const socket of ['cockpit/odoo-tricorder/pty.sock','studio-pty.sock','runtime/pty.sock'])await cleanupBroker(path.join(directory,socket));fs.rmSync(directory,{recursive:true,force:true,maxRetries:5,retryDelay:100});});


test('independent: a rejected queued intention remains recoverable when a later intention succeeds',async()=>{
 await holdNextAdd();await input().fill('A enregistré');await add().click();await waitAck();
 await input().fill('B envoyé avant contribution concurrente');await add().click();
 await input().fill('C envoyé ensuite');await add().click();
 const prior=(await call('run.get',{run:run.id})).run;
 await call('collection.change',{run:run.id,node:'intentions',operation:'add',revision:prior.nodes.intentions.collection.revision,key:'other-agent',text:'X contribution d’un autre collaborateur'});
 await releaseAck();
 await expect.poll(stored).toContain('C envoyé ensuite');
 const saved=await stored(),draft=await input().inputValue(),feedback=await page.locator('#feedback').innerText();
 fs.writeFileSync(test.info().outputPath('queued-conflict.json'),JSON.stringify({saved,draft,feedback},null,2));
 await page.screenshot({path:test.info().outputPath('queued-conflict.png')});
 expect(saved.includes('B envoyé avant contribution concurrente') || draft.includes('B envoyé avant contribution concurrente')).toBe(true);
});

test('independent: a reply for one run preserves another run and its newer draft',async()=>{
 const first=run;
 await holdNextAdd();await input().fill('A à enregistrer dans le premier run');await add().click();await waitAck();
 const graph=await call('workflow.get',{project:project.id,workflow:'collect'});
 const second=await call('run.start',{project:project.id,graph,simulation:true});
 await page.locator('[data-workflow-route=projects]').click();await page.locator('.project-card').filter({hasText:project.title}).click();await page.locator(`[data-action=open-run][data-id="${second.id}"]`).click();await page.getByRole('button',{name:'Détail',exact:true}).click();
 await input().fill('B encore en rédaction dans le second run');await releaseAck();
 await expect.poll(async()=>(await call('run.get',{run:first.id})).run.nodes.intentions.collection.items.map(i=>i.text)).toEqual(['A à enregistrer dans le premier run']);
 await expect(input()).toHaveValue('B encore en rédaction dans le second run');
 await add().click();await expect.poll(async()=>(await call('run.get',{run:second.id})).run.nodes.intentions.collection.items.map(i=>i.text)).toEqual(['B encore en rédaction dans le second run']);
 expect((await call('run.get',{run:first.id})).run.nodes.intentions.collection.items.map(i=>i.text)).toEqual(['A à enregistrer dans le premier run']);
});
