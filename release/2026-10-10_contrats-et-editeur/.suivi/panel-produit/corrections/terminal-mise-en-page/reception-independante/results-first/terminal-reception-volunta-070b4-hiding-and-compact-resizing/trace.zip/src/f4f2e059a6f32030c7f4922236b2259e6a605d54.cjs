const {test,expect,_electron:electron}=require('/home/blegoff/odoo-tricorder/node_modules/@playwright/test');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {cleanupBroker}=require('/home/blegoff/odoo-tricorder/tests/terminal-fixture.cjs');
const root='/home/blegoff/odoo-tricorder';let app,page,directory,project,phases;
const call=(action,data={})=>page.evaluate(payload=>window.studio.request(payload),{action,...data});
const screen=()=>page.locator('.xterm-screen:visible');
async function size(width,height,zoom=1){await app.evaluate(({BrowserWindow},s)=>{const w=BrowserWindow.getAllWindows()[0];w.setContentSize(s.width,s.height);w.webContents.setZoomFactor(s.zoom);},{width,height,zoom});await expect.poll(()=>page.evaluate(()=>innerWidth)).toBe(Math.round(width/zoom));}
async function type(command){await page.locator('.xterm-helper-textarea:visible').focus();await page.keyboard.type(command);await page.keyboard.press('Enter');}
async function phase(label){const data=await page.evaluate(async label=>{const term=globalThis.__reviewTerminal,b=term.buffer.active;const host=document.querySelector('.terminal-host:not([hidden])'),container=document.querySelector('#terminal-hosts'),workflow=document.querySelector('#workflow-panel'),divider=document.querySelector('.terminal-divider');const box=el=>{const r=el.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height};};return {label,width:innerWidth,height:innerHeight,rows:term.rows,cols:term.cols,baseY:b.baseY,viewportY:b.viewportY,cursorY:b.cursorY,visible:document.querySelector('.xterm-screen')?.innerText,host:box(host),container:box(container),workflow:box(workflow),divider:box(divider),bodyHeight:document.body.scrollHeight,sessions:(await window.tricorder.terminals.list()).filter(s=>s.alive).map(s=>({id:s.id,pid:s.pid}))};},label);phases.push(data);return data;}
async function snapshot(label){await phase(label);await page.screenshot({path:test.info().outputPath(label+'.png')});}
async function atBottom(){await expect.poll(()=>page.evaluate(()=>__reviewTerminal.buffer.active.baseY-__reviewTerminal.buffer.active.viewportY)).toBe(0);}
async function useful(){await expect.poll(()=>page.evaluate(()=>__reviewTerminal.rows)).toBeGreaterThanOrEqual(10);const p=await phase('useful-check');expect(p.host.height).toBeGreaterThanOrEqual(140);expect(p.workflow.height).toBeGreaterThanOrEqual(140);}
test.beforeEach(async()=>{
 phases=[];directory=fs.mkdtempSync(path.join(os.tmpdir(),'tricorder-terminal-independent-'));const bin=path.join(directory,'bin');fs.mkdirSync(bin);for(const c of ['codex','claude'])fs.writeFileSync(path.join(bin,c),'#!/bin/sh\nprintf "INERT_REVIEW_PROVIDER\\n"\nexit 78\n',{mode:0o755});
 app=await electron.launch({args:[root],env:{PATH:bin+':/usr/bin:/bin',HOME:directory,DISPLAY:process.env.DISPLAY,XAUTHORITY:process.env.XAUTHORITY,LANG:'C.UTF-8',XDG_CONFIG_HOME:path.join(directory,'config'),XDG_DATA_HOME:path.join(directory,'data'),XDG_CACHE_HOME:path.join(directory,'cache'),CODEX_HOME:path.join(directory,'codex'),CLAUDE_CONFIG_DIR:path.join(directory,'claude'),TRICORDER_HOME:directory,TRICORDER_STATE_DIR:directory,TRICORDER_RUNTIME_DIR:path.join(directory,'runtime'),TRICORDER_AGENTS_DIR:path.join(directory,'no-pack'),TRICORDER_TEST_MODE:'1',PYTHONDONTWRITEBYTECODE:'1'}});
 page=await app.firstWindow();await size(1600,1100);await expect(page.getByRole('heading',{name:'Un workflow clair.'})).toBeVisible();
 // Observation only: retain the real xterm public object from its creation scope.
 // No mock, source rewrite, forced resize or scroll correction is installed.
 const cdp=await app.context().newCDPSession(page),scripts=[];cdp.on('Debugger.scriptParsed',s=>scripts.push(s));await cdp.send('Debugger.enable');const appScript=scripts.find(s=>s.url.endsWith('/app.js'));if(!appScript)throw new Error('app.js not found');const source=(await cdp.send('Debugger.getScriptSource',{scriptId:appScript.scriptId})).scriptSource;const lines=source.split('\n');const mount=lines.findIndex(s=>s.includes('async function mountTerminal('));const line=lines.findIndex((s,i)=>i>mount&&s.includes('cockpitUI.applyPreferences();'));if(line<0)throw new Error('terminal observation point not found');await cdp.send('Debugger.setBreakpoint',{location:{scriptId:appScript.scriptId,lineNumber:line},condition:'globalThis.__reviewTerminal=term, false'});
 await expect(page.getByRole('heading',{name:'Un workflow clair.'})).toBeVisible();await page.locator('[data-action=terminal-toggle]').click();await page.getByRole('button',{name:'Ouvrir un terminal',exact:true}).click();await expect(page.locator('.xterm-helper-textarea:visible')).toBeVisible();await expect.poll(()=>page.evaluate(()=>!!globalThis.__reviewTerminal)).toBe(true);
 await type('printf "SYNTHETIC_TERMINAL_READY\\n"');await expect(screen()).toContainText('SYNTHETIC_TERMINAL_READY');
 project=await call('project.create',{title:'Réception indépendante terminal synthétique'});await call('workflow.save',{project:project.id,graph:{schema:1,id:'review-terminal',title:'Workflow témoin du terminal',nodes:[{id:'source',kind:'task',title:'Recueillir la demande',outputs:{text:'string'},position:{x:60,y:60}},{id:'target',kind:'task',title:'Préparer le plan',inputs:{text:'string'},position:{x:410,y:60}}],edges:[]}});
 await page.locator('[data-action=terminal-toggle]').click();await page.locator('[data-workflow-route=global]').click();await page.locator('[data-action=open-workflow][data-id=review-terminal]').click();await page.locator('[data-action=terminal-toggle]').click();await phase('initial');
});
test.afterEach(async()=>{if(app){if(page&&!page.isClosed()){await phase('final').catch(e=>phases.push({observationError:String(e)}));fs.writeFileSync(test.info().outputPath('phases.json'),JSON.stringify(phases,null,2));}await app.close();}for(const socket of ['cockpit/odoo-tricorder/pty.sock','studio-pty.sock','runtime/pty.sock'])await cleanupBroker(path.join(directory,socket));fs.rmSync(directory,{recursive:true,force:true,maxRetries:5,retryDelay:100});});

test('current output remains followed after compact reopening and keyboard flow control',async()=>{
 await type('for n in {1..24}; do printf "CURRENT_%03d\\n" "$n"; done');await expect(screen()).toContainText('CURRENT_024');await atBottom();const before=await phase('before-hide-current');
 await page.locator('[data-action=terminal-toggle]').click();await size(1024,900,1.25);await page.locator('[data-action=terminal-toggle]').click();await useful();await atBottom();await snapshot('compact-current-before-input');
 await page.locator('.xterm-helper-textarea:visible').focus();await page.keyboard.type("printf '\\x43\\x4f\\x4d\\x50\\x41\\x43\\x54\\x5f\\x4c\\x49\\x56\\x45\\n'");await page.keyboard.press('ArrowLeft');await page.keyboard.press('ArrowRight');await page.keyboard.press('Control+s');await page.keyboard.press('Control+q');await page.keyboard.press('Enter');
 await expect(screen()).toContainText('COMPACT_LIVE');await atBottom();await snapshot('compact-current-after-input');expect((await phase('same-session')).sessions).toEqual(before.sessions);
 await size(1600,1100);await atBottom();await expect(screen()).toContainText('COMPACT_LIVE');
});

test('voluntary history reading is not pulled to the bottom by hiding and compact resizing',async()=>{
 await type('for n in {1..220}; do printf "HISTORY_%03d\\n" "$n"; done');await expect(screen()).toContainText('HISTORY_220');await atBottom();
 await screen().hover();await page.mouse.wheel(0,-900);await expect.poll(()=>page.evaluate(()=>__reviewTerminal.buffer.active.baseY-__reviewTerminal.buffer.active.viewportY)).toBeGreaterThan(20);
 const before=await phase('history-before'),marker=before.visible.match(/HISTORY_\d{3}/)?.[0];expect(marker).toBeTruthy();
 await page.locator('[data-action=terminal-toggle]').click();await size(1024,900,1.25);await page.locator('[data-action=terminal-toggle]').click();await useful();
 const after=await phase('history-after');expect(after.baseY-after.viewportY).toBeGreaterThan(20);expect(after.visible).toContain(marker);expect(after.sessions).toEqual(before.sessions);await snapshot('history-preserved-compact');
});

test('compact split preserves useful terminal size and original PTY through split changes',async()=>{
 const before=await phase('size-before');await page.locator('[data-action=terminal-toggle]').click();await size(1024,900,1.25);await page.locator('[data-action=terminal-toggle]').click();await useful();
 const separator=page.getByRole('separator',{name:'Taille du terminal'});await separator.focus();await page.keyboard.press('Home');await useful();await snapshot('compact-minimum-split');
 await page.keyboard.press('End');await useful();await snapshot('compact-maximum-split');await expect(page.locator('.canvas-area')).toBeVisible();
 await page.getByRole('button',{name:'Agrandir le terminal',exact:true}).click();await expect.poll(()=>page.evaluate(()=>__reviewTerminal.rows)).toBeGreaterThan(25);await page.getByRole('button',{name:'Afficher le workflow',exact:true}).click();await useful();
 await size(1600,1100);await page.getByRole('button',{name:'Disposition verticale',exact:true}).click();await useful();await page.getByRole('button',{name:'Côte à côte',exact:true}).click();await useful();
 expect((await phase('size-after')).sessions).toEqual(before.sessions);await type("printf '\\x50\\x54\\x59\\x5f\\x53\\x54\\x49\\x4c\\x4c\\x5f\\x4c\\x49\\x56\\x45\\n'");await expect(screen()).toContainText('PTY_STILL_LIVE');await snapshot('same-pty-after-layouts');
});
